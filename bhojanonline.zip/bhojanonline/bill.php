<?php
session_start();
if(isset($_SESSION["username"]))
{
}
else
{
	header('Location:user_login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Get My Food Online</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}
</style>
<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>
<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include 'header.php'; ?>
	<br>
	<div class="phead1"><center>Congratulation You Have Sucessfully placed your order details are below.</center></div></br>
<center>	
<table cellpadding="5" cellspacing="5" width="80%" bgcolor="#F4EEED">
<tr>
<th style="background-color:#33cc33;color:white;">Sr. No.</th>
<th style="background-color:#33cc33;color:white;">Product Image</th>
<th style="background-color:#33cc33;color:white;">Product Name</th>
<th style="background-color:#33cc33;color:white;">Price</th>
<th style="background-color:#33cc33;color:white;">Option</th>
<th style="background-color:#33cc33;color:white;">Quantity</th>
<th style="background-color:#33cc33;color:white;">Total</th>
</tr>
<?php
$con=mysqli_connect("localhost","root","","bhojanonline");
$count2 = 1;
$total = 0;
$product_details=null;
 if(isset($_SESSION["cart_item"]))
	  {
           foreach($_SESSION["cart_item"] as $k => $item2)
               {
				   foreach($item2 as $item3 => $item4)
				   {
					$getname = explode("_", $k);
					$sqlstring = "select * from ".$getname[0]." where pname='".$item4."'";
			        $query8=mysqli_query($con, $sqlstring);
                     if(!$query8)
					 {
					 }
					 else
				     {			 
			 	       while($row=mysqli_fetch_array($query8))
		                {
					       echo "<tr align='center'><td align='center'><font color='green' size='4'>".$count2."</font></td><td><img src='".$row['image']."' width='100' height='100'/></td><td><font color='grey' size='4'>".$row['pname']."</font></td><td><font color='grey' size='4'>".$row['price']."Rs</font></td><td>".$item3."</td><td>".($row['price']*$item3)."Rs</td></tr>";
						   $product_details = $product_details."@".$count2.":".$row['pname'].":".$row['price'].":".$item3.":".$row['price'] * $item3;
						   $count2 = $count2 + 1;
                           $total =  $total + ($row['price'] * $item3);					   
	                    }
					 }
				    }
				}  
	  }		
?>
<tr>
<td></td>
<td></td>
<td><font color="green" size="5">Total</font></td>
<td><font color="green" size="5"><?php echo $total; ?>Rs</font></td>
</tr>
</table>
</center>	
<?php
	$name=$_POST['fname'];
	$address=$_POST['address'];
	$mobile=$_POST['mobile'];
	$email=$_SESSION['username'];
	$date1=date('Y-m-d H:i:s');;
	if(isset($_SESSION["cart_item"]))
	{
	$query3=mysqli_query($con, "insert into bill(email,fname,mobile,address,total,date,product_details) values('$email','$name','$mobile','$address','$total','$date1','$product_details')");		
    unset($_SESSION["cart_item"]);
	}
	?>
	<center><br><h2><font type="BOLD" color="green"> Thank you for visiting our BhojanOnline.com...
	Your order will be placed to your respected address within 45 minutes...</font></h2></br>
	<br><br><a href="selectprods.php"><img src="foodimage/conshop.png"></img></a>
	</center>
<?php include 'footer.php'; ?>
</body></html>
