<!DOCTYPE html>
<html>
<head>
    <title>Cancellation Policy</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>


<?php  include "header.php"; ?>
<center>

<h1><font color=red>CANCELLATION POLICY</font></h1>
	
<h4>&nbsp;&nbsp; We make every effort to fulfill all the orders placed. However, please note that there may be certain orders that<br>&nbsp;&nbsp we are unable to process and must cancel.<br>&nbsp;&nbsp;
 <br>&nbsp;&nbsp;The reasons include limitations on quantities available for purchase, inaccuracies or errors in product, pricing and <br>&nbsp;&nbspstock information, or problems identified by  our credit and fraud avoidance department.

<br><br>&nbsp;&nbsp; Our Customer Care Team will communicate to you if all or any portion of your order is cancelled.</h4>

<p><h3><font color=red>Cancellation by the Customer</font></h3>
<h4>&nbsp;&nbsp; Please contact our Customer Care in case you wish to cancel the Order. On receipt of the cancellation notice<br> &nbsp;&nbsp;we shall cancel the order <br><br>&nbsp;&nbsp; We will not be able to cancel orders that have already been processed or shipped out by us.<br>&nbsp;&nbsp; In some cases this can happen  in an hour after you place the order.<h4>


<p>&nbsp;&nbsp; Typically refunds are processed in less than 10 working days but in case of payments by Cheque, it may<br>&nbsp;&nbsp take more time for the Cheque to be delivered to your billing address, and for the funds to be credited to your account, once you deposit the Cheque. <br>&nbsp;&nbsp</h4>
<center>
<?php  include "footer.php"; ?>

</body>
</html>


