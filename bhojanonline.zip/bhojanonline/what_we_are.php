<html>

<head><title>contact_us</title></head>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</br> <h2 style="color:#F00"><center>...About BhojanOnline.com...</center></h2>
<table  align="center"  width="95%" border="0">
  <tr>
    <td><pre>
    <font face="Times New Roman, Times, serif" size="+1">
    BhojanOnline is the online & on-air retail marketing and distribution venture of Network18 Group
    that was launched as India's first 24 hour Home Shopping TV channel on April 9, 2008. BhojanOnline 
    offers innovative, differentiated and demonstrative retail experiences on TV and internet and 
    has emerged as the largest multimedia retailer in India with a user base of 2.5 million 
    users and some  prestigious awards to our credit

    SportGallery is a venture of the Network18 Group, India's fastest growing mediaand entertainment 
    group that operates India's leading business news televisionchannels like CNN-IBN, CNBC TV18 
    and CNBC Awaaz .

    SportGallery has partnered with the best brand owners in India like Puma , Reebok 
    and many more to provide superlative quality and exceptional value for any customer 
	from the stage of product selection, to placing the order & all the way to the final delivery 
	at your doorstep. We come with the trust and credibility that Network18 has built over the years 
	and we strive to create an experience that you can depend upon!

    SportGallery is committed to providing a delightful customer experience, through entertaining and 
    outstanding content on TV & the Web and its high quality captive 24X7 customer service. We 
    maintain highly customer-centric practices, including great products, multiple payment options 
    and 15 days money back guarantee to make shopping with HomeShop18 as an easy, smarter and 
    hassle free experience.

    SportGallery is on a mission to drive India's most comprehensive virtual business 
    that helps customers make informed choices and extract the best value for 
    their money.

    <b>Our Corporate Office address:</b>

    <b style="color:#F39">BhojanOnline.com
    Runal Florance
    Sector-21, C Wing
    Yamunanagar Nigdi Pune-44,
    India.</b> </font></pre>
    
    </td>
    <td valign="top">
    <b style="color:#F39">Shop With confidence</b>
    
	<table width="20%" border="0" bgcolor="#EEE5E3" cellpadding="5" cellspacing="5">
    <tr>
     <td><center><img src="foodimage/thawte_secure.jpg"></center></td>
     <td rowspan="1" ><pre>
     <font face="Times New Roman, Times, serif" size="3">
      SportGallery offers you the 
      highest standard of security
      currently available on the Net 
      so as to ensure that your 
      shopping expernece is Private, 
      Safe and Secure.</font></pre>
     </td>
    </tr>
    <tr>
	<td></td>
     <td><pre>
     <font face="Times New Roman, Times, serif" size="3">
     If, for any reason, you are unsatisfied 
     with your pruchase from HomeShop18, you 
     may return it in its original condition 
     within 15 days for a refund. No questions 
     asked & we'll even pay for return shipping!</font></pre>
     </td>
   </tr>
  </table>
  </td>
  </tr>
 </table>
  <?php include "footer.php"; ?>
  </body>
  </html>
  
