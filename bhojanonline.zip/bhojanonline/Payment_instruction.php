<!DOCTYPE html>
<html>
<head>
    <title>BhojanOnline.com</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php  include "header.php"; ?>
</br>
<center>
<h1>
<font color=red>PAYMENT INSTRUCTIONS
</font>
<p>
<h2>

<blink><font color=blue><h2>BhojanOnline offers Cash on delivery scheme</h2></font></blink><br>

<br>
<font color=red>Paying by Cheque</font></h2>
 <h3> 	 
<br>1. 	You need to draw the cheque for the full amount in favour of " BhojanOnline.com".
<br>2. 	Cheques / Cash can be deposited into BhojanOnline.com account at your nearest ICICI bank branch or ATM against the following account numbers -
  	 
 <br>&nbsp;&nbsp;&nbsp;&nbsp;Our <b>ICICI Bank Acc No. is: 6748369898</b>
<br>Account Name: BhojanOnline.com
<br>RTGS/NEFT/IFSC: ICIC0006285
<br>Branch Name: ICICI Chinchwad BRANCH, NEAR Big Bazar, Chinchwad, Pune.
  	 
  <p>	
<br>(Alternately, you can send the cheque to our office address mentioned below, though this may take longer to process)
  	 
<br>3.Please contact us via email or Phone after submitting the payment so that we can track your payment and begin processing your order.
<br>4.Please mention your Order No. and Invoice No with your cheque details</h3>
  
	 
<!--<h2><font color=red>Paying by Demand Draft</font></h2>
 <h3> 	 
<br>1. 	Draw the Demand Draft for the full order amount in favour of " Sports Gallery PVT. LTD".
<br>2. 	Send the Demand Draft to our office address mentioned below.
<br>3. 	Please contact us via email or Phone after submitting the payment so that we can track your payment and begin processing your order.
<br>4. 	Please mention your Order No. and Invoice No with your DD.<h3>
 --> 	 
<h2><font color=red>Our Address</font></h2>
<h3>  	 
<br>BhojanOnline.com
<br>Runal Florence, Wing-C, Phase 1
<br>Sector No. 21, Second Floor, Nigdi, Pune-411044
  	 
<p><p>  	 
Please call us on 91-020-6332222 or E-mail us at info@bhojanonline.com if you have any questions. </h3>
</center>
<?php  include "footer.php"; ?>
</body>
</html>
