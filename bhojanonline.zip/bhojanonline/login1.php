<?php
session_start();
$_SESSION['eid']=$_POST['email'];
$_SESSION['pswd']=$_POST['password'];

	$fname=$_SESSION['fname'];
	$mob=$_SESSION['mobile'];
	$addr=$_SESSION['addr'];

$con=mysql_connect("localhost","root");
if(!$con)
{
	alert('not conneted');
}

if(isset($_POST['submit']))
{
$eid=$_POST['email'];
$pswd=$_POST['password'];
mysql_select_db("bhojanonline",$con);

$query3=mysql_query("select * from login where(email='".$eid."' and password='".$pswd."')");


$query11=mysql_query("select * from user_info where (email='".$eid."')");

$rows=mysql_fetch_array($query11);
    echo$rows['fname'];
    echo$rows['mobile'];
 echo$rows['address'];
     
   $_SESSION['fname']=$rows['fname'];
	$_SESSION['mobile']=$rows['mobile'];
	$_SESSION['addr']=$rows['address'];

	

if(mysql_fetch_array($query3))
{  
   $sql2="delete from cart";
	mysql_query($sql2,$con);
   
  header('Location:selectsports.php');
}
 else
 {
  header('Location:login.html');
 } 

?>
