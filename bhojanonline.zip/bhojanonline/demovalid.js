function formValidation()  
{  
var uid = document.registration.userid;  
  
var ufname = document.registration.fname;  
var ulname = document.registration.lname; 
var ucity = document.registration.city; 
var upincode = document.registration.pincode;  
var uemail = document.registration.email;  
var uphone = document.registration.phone;
var umobile = document.registration.mobile;

var upassword = document.registration.password;
var ucpassword = document.registration.cpassword;
{  
if(ValidateEmail(uemail))  
{ 
if(allLetter(ufname))  
{  
if(allLetter(ulname))  
{   
if(allLetter(ucity))  
{  
if(allnumeric(upincode))  
{  
if(checkMobile(umobile))  
{  
if(password_validation(upassword,6,15))  
{ 
if(password_validation(ucpassword,6,15))  
{ 
if(checkPassword(upassword,ucpassword))
{
}
}
}  
}   
}  
}   
}  
}  
}  
}  
return false;  
}  



/*function userid_validation(uid,mx,my)  
{  
var uid_len = uid.value.length;  
if (uid_len == 0 || uid_len >= my || uid_len < mx)  
{  
alert("User Id should not be empty / length be between "+mx+" to "+my);  
uid.focus();  
return false;  
}  
return true;  
}  
*/

function password_validation(upassword,mx,my)  
{  
var passid_len = upassword.value.length;  
if (passid_len == 0 ||passid_len >= my || passid_len < mx)  
{  
alert("Password should not be empty / length be between "+mx+" to "+my);  
passid.focus();  
return false;  
}  
return true;  
}  

function allLetter(uname)  
{   
var letters = /^[A-Za-z]+$/;  
if(uname.value.match(letters))  
{  
return true;  
}  
else  
{  
alert('Enter alphabet characters only');  
uname.focus();  
return false;  
}  
}  

/*function alphanumeric(uadd)  
{   
var letters = /^[0-9a-zA-Z]+$/;  
if(uadd.value.match(letters))  
{  
return true;  
}  
else  
{  
alert('User address must have alphanumeric characters only');  
uadd.focus();  
return false;  
}  
}  
*/

function allnumeric(uzip)  
{   
var numbers = /^[0-9]+$/;  
var len = uzip.value.length; 
if (len >6 || len < 6)
{  
alert("Enter valid numeric zip number");  
uzip.focus();  
return false;  
}  
if(uzip.value.match(numbers))  
{  
return true;  
}  
else
{
uzip.focus();  
return false;  
}  
}

function checkMobile(umobile)  
{   
var numbers = /^[0-9]+$/;  
var len = umobile.value.length; 
if (len >10 || len < 10)
{  
alert("Enter valid numeric mobile number");  
umobile.focus();  
return false;  
}  
if(umobile.value.match(numbers))  
{  
	return true;
}
else
{
umobile.focus();  
return false; 
}
  
}

function ValidateEmail(uemail)  
{  
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
if(uemail.value.match(mailformat))  
{  
return true;  
}  
else  
{  
alert("You have entered an invalid email address!");  
uemail.focus();  
return false;  
}  
}  


function checkPassword(upassword,ucpassword)
{
	if(upassword.value==ucpassword.value)
	{
		return true;
	}
	else
	{
		alert("password and confirmed password should be same... please re-enter it");
		upassword.focus();
		return false;
		
	}
}