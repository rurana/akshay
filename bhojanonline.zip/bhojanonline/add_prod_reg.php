<?php
session_start();
if(isset($_SESSION["username"]))
{
}
else
{
	header('Location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>GET MY FOOD ONLINE</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}
</style>
<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>
<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>
<?php include 'header.php'; ?>
</br>
<center><font size="6" color="#FFAB00">INSERT A NEW PRODUCT</font></center><br>
<center>
      <script>
        var loadFile = function(event) {
        var output = document.getElementById('output');
        output.src = URL.createObjectURL(event.target.files[0]);
         };
   </script>
   <img id="output" width='200px' height='200px'/>
<form method="post" action="add_prod.php" enctype="multipart/form-data">
 <table>
  <tr>
   <td>Product Image:</td>
   <td><input type=file name="image" onchange="loadFile(event)"></td>
  </tr>
  <tr></tr>
   <tr>
   <td>category ID:</td>
  <td><select name="category_id" required>
 <?php
 $con=mysqli_connect("localhost","root","","bhojanonline");

     $query11=mysqli_query($con, "select * from category");
	    while($row=mysqli_fetch_array($query11))
		{
          echo "<option value='".$row['category_id']."'>".$row['category_name']."</option>";
		}
	?>
  </select></td>
  </tr>
  <tr></tr>

  <tr>  
    <td>Product Name:</td>
	<td>
	<input type=text name="pname">
	</td>
  </tr>
   <tr></tr>
   <tr>
    <td>Product Price:</td>
	<td><input type=text name="price"></td>
  </tr>
  <tr></tr>
   <tr> 
     <td></td>   
    <td><input type=submit name="submit" value="ADD">
	<input type=reset value=reset></td>
   </tr>
</table>   
</form>
<?php
 if(!empty($_GET['msg']))
 {
  echo "<font color='green'>".$_GET['msg']."</font>";
 }
?>
</center>
<br><br>   
<center><a href="prod_info_op.php"><img src="foodimage/goback1.jpg"></img></a></center>
<?php include "footer.php"; ?>
</body>
</html>
