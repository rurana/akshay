<?php
session_start();
if(isset($_SESSION["username"]) && $_SESSION["usertype"] == "admin")
{
}
else
{
	header('Location:admin_login.php');
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
background:black;
color: white;>
	       <html>
	       <head>
	       <title>Login</title>

	       <style type="text/css">

	       .colour{color: #F00}
       .color2{color: #003}
       .color1{color: #FFF}
       .text1{font-size:24px}
       .look{font-size:14px; color:#333}
       a{ text-decoration:none}

       .border1{border:none; color:#CCC}
       table.menu
       {

position: absolute;
visibility:hidden;
       }

}
</style>


	<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="hidden";
}
</script>
<script type="text/javascript">
function dis()
  {var ob=false;
              
              ob=new XMLHttpRequest();
              var gm=document.getElementById("pid").value;
			  var gm2=document.getElementById("pname").value;
			
              ob.open("GET","searchupdate.php?pid="+gm+"&pname="+gm2);
              ob.send();       
 
              ob.onreadystatechange=function()
              {           if(ob.readyState==4 && ob.status==200)
                          {
                                      document.getElementById("update").innerHTML=ob.responseText;
                          }
              }          
  }
  function re()
  {
	  document.getElementById("update").innerHTML="";
	  document.getElementById("pid").value ="" ;
	  document.getElementById("pname").value ="";
  }
</script>
<link href="js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js-image-slider.js" type="text/javascript"></script>
<link href="generic.css" rel="stylesheet" type="text/css" />
<link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</br>
<center><font size="6" color="#FFAB00"><h1>***UPDATION***</h1></font></center>
<br><br><br>
<form method="POST" action="update_prod.php">
<center><h2>Please Search Product Here First To Update It. Enter Any One Or Both Information.</h2></center>
<center><table>
  <tr>
   <td>Product ID  :</td>
   <td><input type=text name="pid" id="pid"></td>
  </tr>
  <tr></tr>
  <tr></tr>
   <tr>
    <td>Product Name:</td>
	<td><input type=text name="pname" id="pname"></td>
  </tr>
  <tr></tr>
   <tr> 
     <td></td>   
    <td><input type=button name="button" value="Search" onclick="dis()">
	<input type=button value=reset onclick="re()"></td>
   </tr>
</table>   
</center>
</form>
<center>
<?php
if(!empty($_GET['msg']))
{
	echo "<font color='green'>".$_GET['msg']."</font>";
}
?>
</center>
<br>
<span id="update"></span>
<br>   
<center><a href="prod_info_op.php"><img src="foodimage/goback1.jpg"></img></a></center>
<?php include "footer.php"; ?>
</body>
</html>
