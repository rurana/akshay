<?php

$con=mysqli_connect("localhost","root","","bhojanonline");
   
if(!$con)
{
	alert('not conneted');
}

	  $product = $row1['category_name'];
	  if (!empty($_GET['pid']))
        {
		 $pid =   $_GET['pid'];
         $sql1 = "where pid='".$pid."'";
        }
        if (!empty($_GET['pname']))
        {
         $pname = $_GET['pname'];
         $sql1 = "where pname='".$pname."'";
        }
        if (!empty($_GET['pid']) && !empty($_GET['pname']))
        {
	     $pid =   $_GET['pid'];
         $pname = $_GET['pname'];
         $sql1 = "where pname='".$pname."' and pid='".$pid."'";
        }
		$product = $_GET['c'];
		$sqlquery = "DELETE FROM ".$product." ".$sql1;
 if(mysqli_query($con, $sqlquery))
{
	header('Location:remove_search.php?product='.$product.'&pid='.$pid);
}
else
{

	header('Location:remove_search.php?error='.mysqli_error($con).$sqlquery);
}

mysqli_close($con);
?>