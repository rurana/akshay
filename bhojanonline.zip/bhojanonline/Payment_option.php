 <!DOCTYPE html>
<html>
<head>
    <title>Payment OPtions</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php  include "header.php"; ?>
<center>
<br><br><br>
<table>
             
             
	<tr> <tr><b><font color=red>Payment Through Credit Cards</font></b></td>
    </tr>
	<tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
	<tr>
	  <td colspan="2" align="left"><img src="foodimage/Credit-Cards.png" alt="Payment Through Credit Cards"><div style="height:10px"></div></td>
	  </tr>
	<tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
	  <tr>
	  <td colspan="2" class="text5" style="padding: 5px 5px 5px 8px; border: 1px solid rgb(219, 218, 218);">
	   <b><font color=red>Payment Through ATM cum Debit Cards</font></b> </td>
	  </tr>
	<tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
	  <tr>
	    <td colspan="2" align="left"><span class="text1"><div class="text1" style="width:350px; padding:0px 0px 10px 0px">We accept all VISA Debit Cards and Master Debit Cards issued in India by Indian Banks.</div>
	    <img src="foodimage/ATM-cum-Debit-Cards.png" alt="Payment Through ATM cum Debit Cards"><div style="height:10px"></div></td>
	    </tr>
	  <tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
	 <tr>
	  <td colspan="2" class="text5" style="padding: 5px 5px 5px 8px; border: 1px solid rgb(219, 218, 218);">
	   <b><font color=red> Payment Through  Cash Cards</font></b></td>
	  </tr>
	<tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
	  <tr>
	    <td colspan="2" align="left"><img src="foodimage/Cash-Card-Payment-Option.png" alt="Payment Through Cash Cards"><div style="height:10px"></div></td>
	    </tr>
	  <tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
	 <tr>
	  <td colspan="2" class="text5" style="padding: 5px 5px 5px 8px; border: 1px solid rgb(219, 218, 218);">
	    <b><font color=red>Payment Through  Internet Banking</font></b></td>
	  </tr>
	<tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
	  <tr bgcolor="#F2F2F1">
	    <td colspan="2" ><img src="foodimage/Net-Banking.gif" alt="Payment Through Net Banking"><div style="height:10px"></div></td>
	    </tr>
	  <tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
	 <tr>
	  <td colspan="2" class="text5" style="padding: 5px 5px 5px 8px; border: 1px solid rgb(219, 218, 218); ">
	   <b><font color=red> Payment Through Mobile</font></b></td>
	  </tr>
	<tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
	  <tr bgcolor="#F2F2F1">
	    <td colspan="2" ><img src="foodimage/Mobile-Payment-Option.png" alt="Pyment Through Mobiles"><div style="height:10px"></div></td>
	    </tr>
	  <tr>
    <td colspan="2" style="height: 5px;"></td>
    </tr>
		  <tr>
		  <td colspan="2" style="padding: 5px 5px 5px 8px; border: 1px solid rgb(219, 218, 218); "><h2 >Payment Through Transfer Money / Cheque / Cash </h2></td>
		  </tr>
		  
  
  <tr>
    <td class="text4" style="padding: 10px 0px 10px 15px; border: 1px solid rgb(219, 218, 218);" valign="top" width="47%" align="left">
      <span class="text"><strong class="Form_text">Our ICICI Bank Acc No. is:</strong> 6748369898 <br>
      <strong class="Form_text">Account Name:</strong>BhojanOnline.com <br>
      <strong class="Form_text">RTGS / NEFT / IFSC:</strong> IICIC0006285 <br>
      <strong class="Form_text">Branch Name:</strong> ICICI Chinchwad BRANCH, , <br> 
      NEAR Big Bazar, Chinchwad, Pune.</span></td>
    <td class="text" style="padding: 10px 10px 10px 15px; border: 1px solid rgb(219, 218, 218);" valign="top" width="53%" align="justify">
		Cheques / Cash can be deposited into BhojanOnline.com account at your nearest
 ICICI Bank Branch or ATM against the account number mentioned above. 
(Alternately you can send  cheques to our postal address mentioned 
below. You also need to mention your Order No. and Invoice No. in your 
deposit slip while making payment via Cheque.) </td>
  </tr>
 	<tr>
	<td class="text4" style="padding: 5px 10px 10px 15px; border: 1px solid rgb(219, 218, 218);" valign="top" align="justify">
	<strong>Payment Through Demand Draft (DD)<strong></td>
	<td  style="padding: 5px 5px 10px 15px; border: 1px solid rgb(219, 218, 218);"  valign="top" align="left">
	Our Address </td>
 	</tr>
 	<tr>
 	  <td class="text" style="padding: 5px 10px 10px 15px; border: 1px solid rgb(219, 218, 218);  valign="top" align="left">
 	    You can send DD to our postal address mentioned below and make DD in favor of "<strong>Sports Gallery PVT. LTD.</strong>". You also need to mention your Order No. and Invoice No. in your deposit slip while making payment via DD.</td>
 	  <td class="text4" style="padding: 5px 5px 10px 15px; border: 1px solid rgb(219, 218, 218); valign="top" align="left"><b>Sports Gallery PVT. LTD.</b><br>
Runal Florence, Wing-C, Phase 1 <br>
Sector No. 21, Second Floor, Nigdi, Pune-411044</span>
        <hr style="margin:10px 0px 10px 0px; size="1px">
        Please call us on <span class="title_red">91-020-6332222 </span> or E-mail us at<span class="title_red"> info@bhojanOnline.com</span> if you have any questions. </td>
 	</tr>
    <tr>
      <td colspan="2" style="padding: 10px 0px 0px 15px;"><span class="Form_text">NOTE</span>:<span class="text2"> All the Cheques and DDs should be in favour of <strong>"Sports Gallery  PVT. LTD"</strong> payable at Pune </span></td>
    </tr>
</tbody></table>		  
</td>
</tr>
</tbody></table>		</td>
           </tr>

</table>
<center>
<?php  include "footer.php"; ?>
</body></html>
