<?php
session_start();
?>
<!DOCTYPE html>
<html>

<head><title>contact_us</title></head>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</br>
<table align="center" border="1" cellpadding="4" cellspacing="0" width="900">
  <tr>
    <td bordercolor="#000000" align="center" background="foodimage/blue.jpg" valign="middle" height="30"><strong><font color="white">Contact Us</strong></font></td>
  </tr>
  <tr>
 <td align="left">
 <table align="center" border="0" cellpadding="5" cellspacing="0" width="100%">
  </tr>
  <tr colspan="2">
        <td align="left"><strong> <center>
         <h2><font color="red">Our Address</h2></font> </strong>
         <b><h1>BhojanOnline.com...</h1></br>
         Runal Arcade C-8 ,Phase-1 </br>
         Yamunanagar Nigdi Pune-44
         India.</br>
         Tel:+919028511849,+918275200935.</br>
         Fax:+9122 - 24322020</br>
         Email :bhojan_online@gmail.com </b></br> 
		 </center></pre>
 </td>
 </tr>
<tr>
<td>
    <pre><font color="blue" size="3"><b>
    Akash Satav                                                        Rohan Sable</b></font><font color="green">
    402-403 Eden Hall,                                                              402-403 , 
    Model Colony,                                                                   Ganesh Colony,
    pimpri,                                                                         nigdi,
    pune 411 016                                                                    pradhikaran 411 053 
    Mobile : + 91-9028511849                                                        Mobile : + 91-8275200935
    akash.satav@gmail.com                                                           Rohan19@gmail.com</font>
    </pre>
</td>
</tr>
<tr>
<td>	
                                      <pre><font color="blue"><b>
			                          Service Hours </b></font>  <font color="green">
		                              Mon to saturday 10 to 9,
		                              Thusday,sunday 10 to 10,</font></pre>
										  
        </td>
      </tr>
</table>
</tr>
</table>  
<?php include "footer.php"; ?>
</body>
</html>
