<?php

$con=mysqli_connect("localhost","root","","bhojanonline");

if(!$con)
{
	alert('not conneted');
}
if(isset($_POST['submit']))
{

   $category_id=$_POST['category_id'];
   $pname=$_POST['pname'];
   $price=$_POST['price'];
   $image = "foodimage/".$_FILES['image']['name'];
   $query11=mysqli_query($con, "select * from category where category_id='".$category_id."'");
   while($row=mysqli_fetch_array($query11))
	{
    $sql="insert into ".$row['category_name']." values(NULL,'$category_id','$pname','$price','$image')";
     if(mysqli_query($con, $sql))
      {
	  try
	   {
	    move_uploaded_file ($_FILES['image']['tmp_name'], "foodimage/".$_FILES['image']['name']);
	   }
	  catch(Exception $e)
	   {
		header('Location:add_prod_reg.php?msg=Error : '.$e->getMessage());
	   }
	   header('Location:add_prod_reg.php?msg=Sucessfully added '.$pname.' to category '.$row['category_name'].".");
	  }
	  else
	  {
		  header('Location:add_prod_reg.php?msg=Error : '.mysqli_error($con));
	  }
    }
}


mysqli_close($con);


?>

