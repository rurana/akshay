<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>BhojanOnline.com</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include 'header.php' ?>
<br><br>
<center>
   
   <form method="post" action="cart.php">
	<table cellpadding="5" cellspacing="5" width="90%">
   <?php 
$product = $_GET['id'];
$con=mysqli_connect("localhost","root","","bhojanonline");

if(!$con)
{
	alert('not conneted');
}

$query2=mysqli_query($con,"select * from ".$product);
echo "<tr>";
$count = 1;
while($row=mysqli_fetch_array($query2))
{
 if($count <= 3 )
 {
  echo "<td><img src=".$row['image']." width='200' height='150'></td>";
  echo "<td>Name:".$row['pname']."<font color=red>&nbsp;&nbsp;<br><input type=checkbox name='items[]' value='".ucwords(strtolower($row['pname']))."'>Price:Rs.".$row['price']."/-<br></font></td>";
  $count = $count  + 1;
 }
 else
 {
  echo "</tr><tr>";
  $count = 2;
  echo "<td><img src=".$row['image']." width='200' height='150'></td>";
  echo "<td>Name:".$row['pname']."<font color=red>&nbsp;&nbsp;<br><input type=checkbox name='items[]' value='".ucwords(strtolower($row['pname']))."'>Price:Rs.".$row['price']."/-<br></font></td>";
 }
}
?>
</tr>
</table>
<input type="hidden" name="foodtype" value="<?php echo $product; ?>">
</center>
<input type=submit name=submit value="" style="position: fixed; bottom: 0px; right: 0px; background-image:url(foodimage/addtocart.png); width:330px; height:150px; border-width:0px; padding:0px;">
</form>
<?php include "footer.php"; ?>
</body>
</html>