<!--<html>
<head>
<title>About us</title>
</head>
<body background="bd1.jpg">
-->
 <!DOCTYPE html>
<html>
<head>
    <title>About us</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body background="bd1.jpg">

<?php include "header.php"; ?>
</br>
<center>
<h4><font color= red>----ABOUT US----</h4></font>
<font face="Comic Sans MS" size=5>
<br>
Porwal FoodWorks Limited, a Bhardwaj Group Company holds the Master Franchisee Rights for BhojanOnline. The company has been listed on the Indian bourses recently. The promoters of the company are Ms.Rupsi H.Porwal, Ms.Kanchan M.Bhardwaj. 
<br>
<br>
<br>
Porwal Foodworks opened its restaurant in Pune on January 12, 2015. Today according to the Indian Retail Report 2016, we are one of the best food joints in Pune. 
<br>
<br>
<br>
Over the period since 2013, BhojanOnline has remained focused on delivering great tasting Indian food, superior quality, exceptional customer service and value for money offerings. We have endeavored to establish a reputation for being a home delivery specialist capable of delivering parcels within 45 minutes to a community of loyal consumers.
<br>
<br>
<br>
BhojanOnline's vision is focused on " Exceptional people on a mission to be the best food delivery company in the Pune!"  We are committed to bringing fun, happiness and convenience to lives of our consumers by delivering delicious food to their doorstep and our efforts are aimed at fulfilling this commitment towards a large and ever-growing customer base.
<br>
<br>
<br>
BhojanOnline constantly strives to develop products that suit the tastes of our consumers and hence delighting them. BhojanOnline believes strongly in the strategy of 'Think global and act local'. Thus, time and again we have been innovating with delicious new products such as Italian, Chinese cuisines suitable to the taste buds of 21st century Consumers. Further providing value for money and affordable products to our consumers has been an important part of our efforts. Our initiative such as discounts to regular customers has been extremely popular with consumers looking for an affordable and value for money meal option.
<br>
<br>
<br>

Our Brand Positioning of Just in Time Delivery is the attractive benefit we offer to our consumers. All our efforts, whether it is a new innovative and delicious product, offering consumers value for money deals, great service or delivery in 45 minutes are all oriented towards quick delivering to the homes of our consumers.

</font>
</center>
<?php include "footer.php"; ?>
</body>
</html>
