<?php
session_start();
if(isset($_SESSION["username"]))
{
	if($_SESSION["usertype"] == "admin")
	{
	 header('Location:report.php');
	}
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
background:black;
color: white;>
	       <html>
	       <head>
	       <title>Login</title>

	       <style type="text/css">

	       .colour{color: #F00}
       .color2{color: #003}
       .color1{color: #FFF}
       .text1{font-size:24px}
       .look{font-size:14px; color:#333}
       a{ text-decoration:none}

       .border1{border:none; color:#CCC}
       table.menu
       {

position: absolute;
visibility:hidden;
       }

}
</style>


	<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js-image-slider.js" type="text/javascript"></script>
<link href="generic.css" rel="stylesheet" type="text/css" />
<link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</center>
<form name="AdminForm" action="admin.php" method="post">
<body backgroung="z5.jpg">
<table border="0" cellpadding="3" cellspacing="3" width="100%" align="center">
<tr></tr>
<tr></tr>
<tr></tr>


<tr>
<td colspan="2">&nbsp;</td>
</tr>

<tr>
<td style="padding: 0px 30px 0px 0px; border-right: 1px dashed rgb(194, 194, 194);" valign="top" width="40%" align="left">
<table border="0" cellpadding="0" cellspacing="0" width="450px">

<td style="background-image: url('foodimage/top_line.gif'); background-position: center top; background-repeat: repeat-x; height: 13px;" valign="top" align="left">
<?php
	  if(isset($_GET['msg']))
	  {
	  if($_GET['msg'] == 1)
	  {
	  echo "<font color='red'><b>Invalid username or password.</b></font>";
	  }
	  }
	  ?>
<table border="0" cellpadding="10" cellspacing="10" width="100%">

<tbody>
<tr>
<td colspan="2" style="height: 8px;"><div class="text2" align="center"></div></td>
</tr>
<tr>

<td height="21" valign="top" width="19%" align="left">Email ID<font color=red>* </font>:</td>

<td> <input name="eid"  type="text">
</td>
</tr>
<tr>
<td valign="top"  height="21" valign="top" width="19%" align="left">Password<font color=red>*: </font></td>


<td><input name="password"  type="password"></td>
</tr>

<tr>
<td valign="top" align="left">&nbsp;</td>
<td valign="top" align="left">
<div style="padding-top:1px; float:left"><input type=submit value=login name=submit></div>		</td>

</tr>
</table>  </td>
<td style="background-image: url(&quot;foodimage/right_line.gif&quot;); background-repeat: repeat-y; width: 10px;" valign="top" align="left">
<div style="background-image:url(foodimage/top_right.gif); background-position:top right; background-repeat:no-repeat; width:10px; height:19px"></div>				</td>
</tr>

<tr>
<td style="background-image: url(&quot;foodimage/bottom_left_.gif&quot;); background-position: right top; background-repeat: no-repeat; width: 10px; height: 11px;" valign="top" align="right"></td>
<td style="background-image: url(&quot;foodimage/bottom_line.gif&quot;); background-repeat: repeat-x; background-position: center top; height: 11px;"></td>

<td style="background-image: url(&quot;foodimage/bottom_right_.gif&quot;); background-position: right top; background-repeat: no-repeat; width: 10px; height: 11px;"></td>
</tr>
</tbody></table>	</td>



</table>
</form>

<?php include "footer.php"; ?>

</body>

</html>
