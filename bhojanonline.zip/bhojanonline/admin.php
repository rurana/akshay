<?php
session_start();
$con=mysqli_connect("localhost","root","","bhojanonline");

if(!$con)
{
	alert('not conneted');
}
$eid=$_POST['eid'];
$pwd=$_POST['password'];

//$sql="select email,password from admin where email='$eid' and password='$pswd'";
$query1=mysqli_query($con, "select email,password from admin");

while($row=mysqli_fetch_array($query1))
{

	if($row['email']==$eid && $row['password']==$pwd)
	{
		echo $eid;
		$_SESSION['username']= $eid;
        $_SESSION['usertype']= "admin"; 
		header('Location:report.php');
	}
	else
	{

		header('Location:admin_login.php?msg=1');

	}
}
?>
