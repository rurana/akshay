<!--<SCRIPT LANGUAGE=javascript>
function checkEmail(eid) {
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(eid)){
		return (true)
		}
		alert("Invalid E-mail Address! Please re-enter.")
		return (false);
	}

   formObj.actionUpdateData.value="update";
   return true;
}
</SCRIPT>-->
<?php
session_start();
$con=mysqli_connect("localhost","root","","bhojanonline");

if(!$con)
{
	alert('not conneted');
}
$eid=$_POST['eid'];
$password=$_POST['password'];
//mysql_select_db("bhojanOnline",$con);

$query2=mysqli_query($con,"select * from login");

while($row=mysqli_fetch_array($query2))
{
	if($row['eid']==$eid && $row['password']==$password)
      {
		$_SESSION['username']= $eid;
        $_SESSION['usertype']= "user";  		
      header('Location:selectprods.php');
      }
	else
	{
      header('Location:user_login.php?msg=1');

	}
}

?>

