<?php
$con=mysqli_connect("localhost","root","","bhojanonline");
  $query1=mysqli_query($con, "select * from category");
  echo "<table border=1 width='500' align='center'><tr><th>Sr. No</th><th>Image</th><th>Category ID</th><th>Product Name</th><th>Price</th><th>Option</th><</tr>";
  $cnt=1;
		
  while($row1=mysqli_fetch_array($query1))
  {
	  $product = $row1['category_name'];
		if (!empty($_GET['pid']))
        {
		 $pid =   $_GET['pid'];
         $sql1 = "select * from ".$product." where pid='".$pid."'";
		 $getstr = "pid=".$pid;
        }
        if (!empty($_GET['pname']))
        {
         $pname = $_GET['pname'];
         $sql1 = "select * from ".$product." where pname='".$pname."'";
		 $getstr = "pname=".$pname;
        }
        if (!empty($_GET['pid']) && !empty($_GET['pname']))
        {
	     $pid =   $_GET['pid'];
         $pname = $_GET['pname'];
         $sql1 = "select * from ".$product." where pname='".$pname."' and pid='".$pid."'";
		 $getstr = "pid=".$pid."&pname=".$pname;
        }
       $sqlquery=mysqli_query($con, $sql1);
	                                      		
       while($row=mysqli_fetch_array($sqlquery))
		{
			
			echo "<tr><td align='center'><font color='green' size='4'>".$cnt."</font></td><td><img src='".$row['image']."' width='100' height='100'/></td><td><font color='grey' size='4'>".$row['category_id']."</font></td><td><font color='grey' size='4'>".$row['pname']."</font></td><td><font color='grey' size='4'>".$row['price']."Rs</font></td><td><a href='update_prod_data.php?".$getstr."&product=".$product."'>Update</a></td></tr></tr>";
			
			$cnt+=1;                 
		}
  }
?>