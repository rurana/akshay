<?php
session_start();
if(isset($_SESSION["username"]))
{
}
else
{
	header('Location:user_login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>BhojanOnline.com</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}
</style>
<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>
<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include 'header.php' ?>
</br>
<center> <h1><font color="pink" > Your Cart contains following Items...</font></h1></center>
   <br>
   <br>
  <center> 

<table cellpadding="5" cellspacing="5" width="80%" bgcolor="#F4EEED">
<tr>
<th style="background-color:#33cc33;color:white;">Sr. No.</th>
<th style="background-color:#33cc33;color:white;">Product Image</th>
<th style="background-color:#33cc33;color:white;">Product Name</th>
<th style="background-color:#33cc33;color:white;">Price</th>
<th style="background-color:#33cc33;color:white;">Option</th>
<th style="background-color:#33cc33;color:white;">Quantity</th>
<th style="background-color:#33cc33;color:white;">Total</th>
</tr>
<?php 
$con=mysqli_connect("localhost","root","","bhojanonline");
if(isset($_POST["items"]))
{
	$foodtype = $_POST['foodtype'];
	
		foreach($_POST["items"] as $item)
	     {
			
			 $sqlstring = "select * from ".$foodtype;
			 $query8=mysqli_query($con, $sqlstring);
			 
			 	while($row=mysqli_fetch_array($query8))
		           {
					 if ($row['pname'] == $item)
                     {	
				      $new_product['product_code'] = $foodtype."_".$item;
					  $new_product['product_quantity'] = "1";
			          $_SESSION['cart_item'][$new_product['product_code']][$new_product['product_quantity']]= $item;
				     }			
	               }
		 }
			 
}
$count2 = 1;
$total = 0;
 if(isset($_SESSION["cart_item"]))
	  {
           foreach($_SESSION["cart_item"] as $k => $item2)
               {
				   foreach($item2 as $item3 => $item4)
				   {
					
				    $getname = explode("_", $k);
					$sqlstring = "select * from ".$getname[0]." where pname='".$item4."'";
			        $query8=mysqli_query($con, $sqlstring);
			        if(!$query8)
					{
					}
					else
				    {
			 	    while($row=mysqli_fetch_array($query8))
		                {
					       echo "<tr align='center'><td align='center'><font color='green' size='4'>".$count2."</font></td><td><img src='".$row['image']."' width='100' height='100'/></td><td><font color='grey' size='4'>".$row['pname']."</font></td><td><font color='grey' size='4'>".$row['price']."Rs</font></td><td><a href='removep.php?p=".$k."'>Remove</a></td><td><a href='addquantity.php?n=".$k."&q=".$item3."&i=".$item4."'><img src='foodimage/add.png' style='vertical-align:top;background-color:green;'></a>&nbsp;".$item3."&nbsp;<a href='minusquantity.php?n=".$k."&q=".$item3."&i=".$item4."'><img src='foodimage/minus.png' style='vertical-align:bottom;background-color:green;'></a></td><td>".($row['price']*$item3)."Rs</td></tr>";
						   $count2 = $count2 + 1;
                           $total =  $total + ($row['price'] * $item3);					   
	                    }
				   }
				
				   }
                }
	  }				

	
			 

	
?>
<tr>
<td></td>
<td></td>
<td><font color="green" size="5">Total</font></td>
<td><font color="green" size="5"><?php echo $total; ?>Rs</font></td>
<td></td>
</tr>
</table>
   </center>
     <br><br><br><br><br>
	<pre>
<center>
<?php if($total == 0 ) { ?>
<a href="selectprods.php"><img src="foodimage/continue.gif" height="100" width="250"></img></a>
<?php } else { ?>
<a href="selectprods.php"><img src="foodimage/continue.gif" height="100" width="250"></img></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="check.php" ><img src="foodimage/proceed.jpeg" height="100" width="250"></img></a>
<?php } ?>
</center>
</body>
</html>
