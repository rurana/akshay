<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head><title>feedback form</title></head>
<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</br>
<form name="feddbackForm" action="feedback.php" method="post">
<b>
<center>
<form method=post name=valid action="">
<table cellpadding="5" cellspacing="5">

<tr>
	<td><font color=red>*</font>Your Name</td> <td>:</td> <td><input type=text name=fname size=48></td>
</tr>

<tr>
	<td><font color=red>*</font>Email Id</td> <td>:</td> <td><input type=text name=email size=48></td>
</tr>

<tr>
	<td><font color=red>*</font>Address</td><td>:</td> <td><textarea name=address rows=5 cols=50></textarea></td> 
    </tr>

<tr><td><font color=red>*</font>Mobile</td>  <td>:</td><td><input type=text name=mobile size=48></td></tr>

<tr></tr>
<tr>
	<td><font color=red>*</font>Your Message </td><td>:</td> <td><textarea name=msg rows=20 cols=50></textarea></td> 
    </tr>

<tr></tr>
<tr>
<td></td><td></td>	<td><input type=submit name=submit value="" style="background-image:url(foodimage/submit.jpg);width:95px; height:24px; border-width:0px; padding:0px">
<input type=reset name=reset value="" style="background-image:url(foodimage/reset.jpg);width:85px; height:24px; border-width:0px; padding:0px"></td>
             
</tr>
</table>
</b>
</form>
<?php include "footer.php"; ?>
</body>
</html>
	
