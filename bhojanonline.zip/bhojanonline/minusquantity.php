<?php
session_start();
$quantity = $_GET['q'];
$name = $_GET['n'];
$item = $_GET['i'];
echo  $quantity." ".$name." ".$item;
if ($quantity == "1")
{
	unset($_SESSION['cart_item'][$name]);
}
else
{
	$new_product['product_code'] = $name;
	unset($_SESSION['cart_item'][$name]);
    $new_product['product_quantity'] = $quantity - 1 ;
	$_SESSION['cart_item'][$new_product['product_code']][$new_product['product_quantity']] = $item;
}
header("location:cart.php");
?>