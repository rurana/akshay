<?php

$con=mysqli_connect("localhost","root","","bhojanonline");

if(!$con)
{
	alert('not conneted');
}
if(isset($_POST['submit']))
{
   $pid=$_POST['pid'];
   $pname=$_POST['pname'];
   $price=$_POST['price'];
   $category_id=$_POST['category_id'];
   $image = "foodimage/".$_FILES['image']['name'];
   if(empty($_FILES['image']['name']))
   {
	  $str1 = "pname='$pname', category_id='$category_id', price='$price'";
   }
   else
   {
	   $str1 = "pname='$pname', category_id='$category_id', price='$price', image='$image'";
   }
   $query11=mysqli_query($con, "select * from category where category_id='".$category_id."'");
    while($row=mysqli_fetch_array($query11))
	{
      $sql="UPDATE ".$row['category_name']." SET ".$str1." WHERE pid='$pid'";
     if(mysqli_query($con, $sql))
   	  {
	  try
	   {
	    move_uploaded_file ($_FILES['image']['tmp_name'], "foodimage/".$_FILES['image']['name']);
	   }
	  catch(Exception $e)
	   {
		header('Location:update_prod_search.php?msg=Error : '.$e->getMessage());
	   }
	  header('Location:update_prod_search.php?msg=Sucessfully Updated '.$pname.' to category '.$row['category_name'].".");
	  }
	  else
	  {
		  header('Location:update_prod_search.php?msg=Error : '.mysqli_error($con));
	  }
    }
}
mysqli_close($con);
?>