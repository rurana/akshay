<!DOCTYPE html>
<html>
<head>
    <title>BhojanOnline.com</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>

</br>
<center>
<h1><font color=red>TERMS AND CONDITIONS OF USE OF THIS SITE</font></h1>
<table align="center" width="90%">	
<p>		
Welcome to the BhojanOnline and services provided by BhojanOnline.<br> In using the BhojanOnline services, of BhojanOnline.com you are deemed to have accepted the terms and conditions listed below.
<p>
All products or services and information displayed on BhojanOnline constitute an "invitation to offer".<br> Your order for purchase constitutes your "offer" which shall be subject to the terms and conditions as listed below.  BhojanOnline reserves the<br> right to accept or reject your offer.

<p><h2><font color=red>Membership Eligibility</font></h2>
<p>
Use of the Site is available only to persons who can form legally binding contracts under applicable law.<br> If you are a minor i.e. under the age of 18 years but at least 13 years of age you may use this Site only under the supervision of a parent or<br> legal guardian who agrees to be bound by these Terms of Use. If your age is below that of 18 years your parents or legal guardians can<br> transact on behalf of you if they are registered users.<br>
BhojanOnline reserves the right to terminate your membership and refuse to provide you with access<br> to the Site if BhojanOnline discovers that you are under the age of 18 years. The Site is not available to persons whose membership <br>has been suspended or terminated by BhojanOnline for any reason whatsoever. <br> <b>BhojanOnline will deliver the products only within pune and will not be liable for any claims relating to any products ordered from outside Pune.</b>

<p><h2><font color=red>Account and Registration Obligations</font></h2>
<p>
"Your Information" is defined as any information you provide to us in the registration, buying or listing<br> process, in the feedback area or through any email feature. We will protect Your Information in accordance with our Privacy Policy.<br> If you use the Site, you are responsible for maintaining the confidentiality of Your Account and Password and for restricting access to <br>your computer, and you agree to accept responsibility for all activities that occur under Your Account or Password. <br>
You also agree to:<br>
    Provide true, accurate, current and complete information about yourself as prompted by BhojanOnline<br> registration form (such information being the "Registration Data")<br>
    Maintain and promptly update the Registration Data to keep it true, accurate, current and complete. <br>If you provide any information that is untrue, inaccurate, incomplete, or not current or if BhojanOnline has reasonable grounds to suspect <br>that such information is untrue, inaccurate and not current or not in accordance with the User Agreement, BhojanOnline has the right <br>to indefinitely suspend or terminate your membership and refuse to provide you with access to the Site.<br>
<p><h2><font color=red>Pricing Information</font></h2><br>
While BhojanOnline strives to provide accurate product and pricing information, pricing or typographical<br> errors may occur. BhojanOnline cannot confirm the price of a product until after you order. In the event that a product is listed at an <br>incorrect price or with incorrect information due to an error in pricing or product information, BhojanOnline shall have the right, at our <br>sole discretion, to refuse or cancel any orders placed for that product, unless the product has already been dispatched. <br> Unless the payment <br>for the product(s) ordered by you has been accepted, your offer will not be deemed accepted and BhojanOnline <br>will have the right to<br> modify the price of the product and contact you for further instructions using the e-mail address provided by you during the time of <br>registration, or cancel the order and notify you of such cancellation.  Some situations that may result in your order being<br> canceled include limitations on quantities available for purchase, inaccuracies or errors in product or pricing information, or problems identified by <br>our credit and fraud avoidance department. <br>

<p><h2><font color=red>Cancellations by the Customer</font></h2><br>
In case we receive a cancellation notice and the order has not been processed or approved by us, we shall <br>cancel the order and refund the entire amount. We will not be able to cancel orders that have already been processed and shipped out by us. <br>BhojanOnline has the full right to decide whether an order has been processed or not. The customer agrees not to dispute the decision made by <br>BhojanOnline and accept BhojanOnline�s decision regarding the cancellation.

<p><h2><font color=red>Fraudulent or Declined Transactions</font></h2><br>
BhojanOnline reserves the right to recover the cost of goods, collection charges and lawyers fees from persons <br>using the Site fraudulently. BhojanOnline reserves the right to initiate legal proceedings against such persons for fraudulent use of the Site and<br> any other unlawful acts or acts or omissions in breach of these terms and conditions.

<p><h2><font color=red>You Agree and Confirm</font></h2><br>
    That in the event that a non-delivery occurs on account of a mistake by you (i.e. wrong name or address or any other <br>wrong information) any extra cost incurred by BhojanOnline for redelivery shall be claimed from you.<br>
    That you will use the services provided by BhojanOnline, its affiliates, consultants and contracted companies, for <br>lawful purposes only and comply with all applicable laws and regulations while using the Site and transacting on the Site.<br>
    You will provide authentic and true information in all instances where such information is requested of you. <br>BhojanOnline reserves the right to confirm and validate the information and other details provided by you at any point of time.<br>
    
<p><h2><font color=red>Modification of Terms & Conditions of Service</font></h2><br>
BhojanOnline may at any time modify the Terms & Conditions of Use of the site without any prior notification <br>to you. You can access the latest version of the User Agreement at any given time on BhojanOnline. You should regularly review the Terms & Conditions<br> on BhojanOnline.

<p><h2><font color=red>Limitation of Liability and Disclaimers</font></h2><br>
The Site is provided without any warranties or guarantees and in an "As Is" condition. You must bear the risks associated <br>with the use of the Site. The Site provides content from other Internet sites or resources and while BhojanOnline tries to ensure that <br>material included on the Site is correct, reputable and of high quality, it cannot accept responsibility if this is not the case. <br>BhojanOnline will not be <br>responsible for any errors or omissions or for the results obtained from the use of such information or for<br> any technical problems you may experience with the Site.

<h1><a href="register.php">Back</img>
</table>
</center>
<?php include "footer.php"; ?>
</body>
</html>
