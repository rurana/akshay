<?php
session_start();
if(isset($_SESSION["username"]))
{
}
else
{
	header('Location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>BhojanOnline.com</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}
</style>
<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>
<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>
<?php include 'header.php'; ?>
</br>
<center><h1>USER'S BILL REPORT</h1><br><br>
<table cellpadding="5" cellspacing="5">
<tr><td align="center">Report Date :<?php echo date('m/d/Y h:i:s a', time()); ?></td></tr>
<tr>

<td>
<?php
$con=mysqli_connect("localhost","root","","bhojanonline");

     $query11=mysqli_query($con, "select * from bill where email='".$_SESSION['username']."'");
	                                      
		
		$cnt=1;
		
		echo "<table border=1><tr><th>Sr. No</th><th>BNO</th><th>DATE</th><th>EMAIL</th><th>Mobile No.</th><th>TOTAL AMOUNT</th><th>Details</th></tr>";
		while($row=mysqli_fetch_array($query11))
		{
	    $posturl1 = str_replace(" ","%20",$row['product_details']);
		$posturl = substr($posturl1, 1);
	    echo "<tr><td>".$cnt."</td><td>".$row['bno']."</td><td>".$row['date']."</td><td>".$row['email']."</td><td>".$row['mobile']."</td><td>".$row['total']."Rs</td><td><a href='product_details.php?d=".$posturl."'>View Details</a></td></tr>";

		$cnt+=1;                 
		}
		echo "</table>";
     mysqli_close($con);
	
	
?></td></tr>
<tr>
</center></table>
<center><a href="selectprods.php"><img src="foodimage/goback1.jpg"></img></a></center>
<?php include 'footer.php'; ?>
 </body>
</html>
