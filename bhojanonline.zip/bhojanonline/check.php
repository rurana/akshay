<?php
session_start();
if(isset($_SESSION["username"]))
{
	
}
else
{
	header('Location:selectprods.php');
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
	background:black;
	color: white;>
<html>
<head>
    <title>Login</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

}
</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include 'header.php'; ?>
</br>
<center><h4><font color=red>Billing Details </h4></font></center>
<center>
 <?php
  	  $fname = NUlL;
	  $address = NULL;
	  $mobile = NULL;
  $con=mysqli_connect("localhost","root","","bhojanonline");
  $sqlstring = "select * from user_info where eid='".$_SESSION['username']."'";
  $query8=mysqli_query($con, $sqlstring);
  while($row=mysqli_fetch_array($query8))
  {
	  $fname = $row['fname'];
	  $address = $row['address'];
	  $mobile = $row['m'];
  }
 ?>
 <form action="bill.php" method="post">
  <table>
	<tr>
	<td>Enter your name:</td><td><input type=text name=fname size=48 value="<?php echo $fname; ?>" required/></td>
	</tr><tr>
	<td>Enter your address:</td><td><input type=textarea name="address" rows="30" cols="60" value="<?php echo $address; ?>" required/></td>
	</tr><tr>
	<td>Enter your phone no:</td><td><input type=text name=mobile size=48 value="<?php echo $mobile; ?>" required/></td>
    </tr>
  </table>
  	<a href="cart.php"><img src="foodimage/goback1.jpg"/></img></a>
	<input type="image" name="submit" value="submit" src="foodimage/proceed2.jpeg"/>
</form>

<center>	
<?php include 'footer.php'; ?>
</body></html>
	
