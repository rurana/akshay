<?php
session_start();
if(isset($_SESSION["username"]) && $_SESSION["usertype"] == "admin")
{
}
else
{
	header('Location:admin_login.php');
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
background:black;
color: white;>
	       <html>
	       <head>
	       <title>Login</title>

	       <style type="text/css">

	       .colour{color: #F00}
       .color2{color: #003}
       .color1{color: #FFF}
       .text1{font-size:24px}
       .look{font-size:14px; color:#333}
       a{ text-decoration:none}

       .border1{border:none; color:#CCC}
       table.menu
       {

position: absolute;
visibility:hidden;
       }

}
</style>


	<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js-image-slider.js" type="text/javascript"></script>
<link href="generic.css" rel="stylesheet" type="text/css" />
<link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
<center><font size="6" color="#FFAB00">PRODUCT INFORMATION</font>
<a href="prod_info_op.php"><img src="images/goback1.jpg"></img></a><br>

<?php

$con=mysqli_connect("localhost","root","","bhojanonline");

  $query1=mysqli_query($con, "select * from category");
  echo "<table border=1 width='500' align='center'><tr><th>Sr. No</th><th>image</th><th>PID</th><th>PNAME</th><th>PRICE</th></tr>";
  $cnt=1;
  while($row=mysqli_fetch_array($query1))
  {
	 $product = $row['category_name'];
     $query4=mysqli_query($con, "select * from ".$product);
	                                      		
		
		while($row=mysqli_fetch_array($query4))
		{
			
			echo "<tr><td align='center'>$cnt</td><td align='center'><img src='".$row['image']."' width='100' height='100'/></td><td align='center'>".$row['pid']."</td><td align='center'>".$row['pname']."</td><td align='center'>".$row['price']."</td></tr>";
			
			$cnt+=1;                 
		}
		
  }
  echo "</table>";
     mysqli_close($con);
	
	
?>
</center>
 <?php include "footer.php"; ?>
</body>
</html>
