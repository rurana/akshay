<?php
session_start();
if(isset($_SESSION["username"]) && $_SESSION["usertype"] == "admin")
{
}
else
{
	header('Location:admin_login.php');
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
background:black;
color: white;>
	       <html>
	       <head>
	       <title>Login</title>

	       <style type="text/css">

	       .colour{color: #F00}
       .color2{color: #003}
       .color1{color: #FFF}
       .text1{font-size:24px}
       .look{font-size:14px; color:#333}
       a{ text-decoration:none}

       .border1{border:none; color:#CCC}
       table.menu
       {

position: absolute;
visibility:hidden;
       }

}
</style>


	<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js-image-slider.js" type="text/javascript"></script>
<link href="generic.css" rel="stylesheet" type="text/css" />
<link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</br>
<center><h1>FEED BACK FORM</h1><br>
<?php

$con=mysqli_connect("localhost","root","","bhojanonline");



     $query9=mysqli_query($con, "select * from feedback");
	                                       
		
		$cnt=1;
		echo "<table border=1><tr><th>Sr. No</th><th>NAME</th><th>Email</th><th>Address</th><th>Mobile</th><th>Massage</tr>";
		while($row=mysqli_fetch_array($query9))
		{
			
			echo "<tr><td>$cnt</td><td>".$row['fname']."</td><td>".$row['emid']."</td><td>".$row['address']."</td><td>".$row['mobile']."</td><td>".$row['msg']."</td></tr>";
			
			$cnt+=1;                 
		}
		echo "</table>";
     mysqli_close($con);
	
	
?>
   </center><table>
   </br>
   <center><a href="report.php"><img src="foodimage/goback1.jpg"></img></a></center>
<?php include "footer.php"; ?>
</body>
</html>
