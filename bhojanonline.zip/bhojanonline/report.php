<?php
session_start();
if(isset($_SESSION["username"]) && $_SESSION["usertype"] == "admin")
{
}
else
{
	header('Location:admin_login.php');
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
background:black;
color: white;>
	       <html>
	       <head>
	       <title>Login</title>

	       <style type="text/css">

	       .colour{color: #F00}
       .color2{color: #003}
       .color1{color: #FFF}
       .text1{font-size:24px}
       .look{font-size:14px; color:#333}
       a{ text-decoration:none}

       .border1{border:none; color:#CCC}
       table.menu
       {

position: absolute;
visibility:hidden;
       }

}
</style>


	<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js-image-slider.js" type="text/javascript"></script>
<link href="generic.css" rel="stylesheet" type="text/css" />
<link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
<center>
</br>
<font size="6" color="#FFAB00"><h3>Welcome To Admin Panel Please Select Option Below.</h3></font>
</center>
<center>
<table>
<tr><td><a href="prod_info_op.php"><img src="foodimage/clickme1.jpg"></img></a></td> 
<td><font size="4" color="Green"><h3>Product INFO/ADD/UPDATE/DELETE<h3></font></td></tr><tr></tr><tr></tr>
<tr><td><a href="user_bill_admin.php"><img src="foodimage/clickme2.jpg"></img></a> </td> 
<td><font size="4" color="Green"><h3>User Bill Information<h3></font></td></tr><tr></tr><tr></tr>
<tr><td><a href="checkUser.php"><img src="foodimage/info2.jpg"></img></a></td> 
<td><font size="4" color="Green"><h3>User Information</h3></font></td></tr><tr></tr><tr></tr>
<tr><td><a href="user_feed.php"><img src="foodimage/feedback1.jpg"></img></a></td> 
<td><font size="4" color="Green"><h3>See FeedBack</h3></font></td></tr><tr></tr><tr></tr>
</table>
</center>

<?php include "footer.php"; ?>
</body></html>
