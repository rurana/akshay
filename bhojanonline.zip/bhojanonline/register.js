function validation()
{
   
   
    var eid=document.register.eid.value;

   var fname=document.register.fname.value;
   var lname=document.register.lname.value;
   var pincode=document.register.pincode.value;
   var phone=document.register.phone.value;
   var mobile=document.register.mobile.value;
   var city=document.register.city.value;
   var password=document.register.password.value;
   
   var email=/^\w(\.?[\w-])*@\w(\.?[\w-])*\.[a-z]{2,6}(\.[a-z]{2})?$/i;


      if(!eid=="")
     {
	    var e1=eid.split(";");
       for(var i=0;i<(e1.length);i++)
       {
         if(!email.test(e1[i]))
         {
            
          alert("Plz enter valid email......!!");
		  document.register.eid.focus();
          document.register.eid.select();
          
          return false;
		 }	
		 
	  }
	 }
	       
     if(eid=="")
     {
	 alert("Text should not be empty");
	   document.register.eid.focus();
       document.register.eid.select();
       
       return false;
     }
       
     
 
    
     
      if(!fname=="")
     {
       
	 }
	 
	 if(fname=="")
	 {
	   alert("Text should not be empty");
       document.register.fname.focus();
       document.register.fname.select();
       return false;
	 } 
	   

	  if(lname=="")
     {
       alert("Text should not be empty");
       document.register.lname.focus();
       document.register.lname.select();
       return false;
     } 
     
      if(pincode=="")
     {
       alert("Text should not be empty");
       document.register.pincode.focus();
       document.register.pincode.select();
       return false;
     } 
     
      if(phone=="")
     {
       alert("Text should not be empty");
       document.register.phone.focus();
       document.register.phone.select();
       return false;
     } 
     
      if(mobile=="")
     {
       alert("Text should not be empty");
       document.register.mobile.focus();
       document.register.mobile.select();
       return false;
     } 
     
      if(city=="")
     {
       alert("Text should not be empty");
       document.register.city.focus();
       document.register.city.select();
       return false;
     } 
}