<?php
session_start();
if(isset($_SESSION["username"]) && $_SESSION["usertype"] == "admin")
{
}
else
{
	header('Location:admin_login.php');
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
background:black;
color: white;>
	       <html>
	       <head>
	       <title>Login</title>

	       <style type="text/css">

	       .colour{color: #F00}
       .color2{color: #003}
       .color1{color: #FFF}
       .text1{font-size:24px}
       .look{font-size:14px; color:#333}
       a{ text-decoration:none}

       .border1{border:none; color:#CCC}
       table.menu
       {

position: absolute;
visibility:hidden;
       }

}
</style>


	<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="hidden";
}
</script>
<script type="text/javascript">
function dis()
  {var ob=false;
              ob=new XMLHttpRequest();
              var gm=document.getElementById("pid").value;
              ob.open("GET","searchremove.php?pid="+gm);
              ob.send();       
 
              ob.onreadystatechange=function()
              {           if(ob.readyState==4 && ob.status==200)
                          {
                                      document.getElementById("remove").innerHTML=ob.responseText;
                          }
              }          
  }
</script>

<link href="js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js-image-slider.js" type="text/javascript"></script>
<link href="generic.css" rel="stylesheet" type="text/css" />
<link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</br>
<center>
<h2><font color="green"><strong>User Information</strong></font></h2>
</br></br>
<table border="1" width="90%">
<tr>
<th>First Name</th>
<th>Last Name</th>
<th>Email ID</th>
<th>Address</th>
<th>State</th>
<th>City</th>
<th>Pin Code</th>
<th>Tele Phone NO</th>
<th>Mobile NO</th>
<th>Passoword</th>
</tr>
<?php
      $con=mysqli_connect("localhost","root","","bhojanonline");
      $query4=mysqli_query($con, "SELECT * FROM `user_info`");
		while($row=mysqli_fetch_array($query4))
		{
				echo "<tr><td>".$row['fname']."</td><td>".$row['lname']."</td><td>".$row['eid']."</td><td>".$row['address']."</td><td>".$row['state']."</td><td>".$row['city']."</td><td>".$row['pincode']."</td><td>".$row['phone']."</td><td>".$row['m']."</td><td>".$row['password']."</td></tr>";
			
		}
?>
</table>
</center>
</br>
<center><a href="report.php"><img src="foodimage/goback1.jpg"></img></a></center>
<?php include "footer.php"; ?>
</body>
</html>

