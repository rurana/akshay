<?php
$con=mysqli_connect("localhost","root","","bhojanonline");
if(!$con)
{
	alert('not conneted');
}
if(isset($_POST['submit']))
{
$eid=$_POST['email'];
$fname=$_POST['fname'];
$address=$_POST['address'];
$mobile=$_POST['mobile'];
$msg=$_POST['msg'];
$sql="insert into feedback values('$fname','$eid','$address','$mobile','$msg')";

 if(mysqli_query($con, $sql))
{
	
  header('Location:index.php');
}
else
{
	//echo "your registration is failed... please try again!!!";

     
	 //<a href="register.html"><input type=submit value=back></a>
	 echo mysqli_error($con);
	// header('Location:feedback.php');
}

}
mysqli_close($con);

//echo "<h1>You have been successfully registered...<br>Now You can Login to our Web site..";

?>

