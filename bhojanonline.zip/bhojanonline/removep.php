<?php
   session_start();
   $str =$_GET['p'];

	unset($_SESSION['cart_item'][$str]);
	header("location:cart.php");
?>