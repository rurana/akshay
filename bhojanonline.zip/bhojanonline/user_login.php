<?php
session_start();
if(isset($_SESSION["username"]))
{
	header('Location:selectprods.php');
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
	background:black;
	color: white;>
<html>
<head>
    <title>Login</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

}
</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include 'header.php'; ?>
</br>

<form name="LoginForm" action="login.php" method="post">
<table border="0" cellpadding="3" cellspacing="3" width="100%">
<tr></tr>
<tr></tr>
<tr></tr>
<tr>
    <td style="padding: 0px 0px 0px 20px; background-color: rgb(242, 241, 241); height: 30px;" valign="middle" align="left">
	<h2>I am Already Registered</h2></td>
    <td style="padding: 0px 0px 0px 20px; background-color: rgb(242, 241, 241); height: 30px;" valign="middle" align="left">
	<h2>I want to Register</h2>	</td>
  </tr>

 <tr>
   <td colspan="2">&nbsp;</td>
 </tr>

  <tr>
    <td style="padding: 0px 30px 0px 0px; border-right: 1px dashed rgb(194, 194, 194);" valign="top" width="40%" align="left">
	<table border="0" cellpadding="0" cellspacing="0" width="450px">
             
 <td style="background-image: url(&quot;top_line.gif&quot;); background-position: center top; background-repeat: repeat-x; height: 13px;" valign="top" align="left">
 <table border="0" cellpadding="10" cellspacing="10" width="100%">

	<tbody><tr>
	<td  colspan="2" class="text4"><font color=red>Existing Customers -</font><br> Login to your BhojanOnline.com account here for a convenient checkout. </td>
	</tr>
	<tr>
	  <td  colspan="2" style="height: 8px;"><div class="text2" align="center"></div></td>
	  </tr>
	  <tr>
	  <td colspan="2">
	        <?php
	  if(isset($_GET['msg']))
	  {
	  if($_GET['msg'] == 1)
	  {
	  echo "<font color='red'><b>Invalid username or password.</b></font>";
	  }
	  }
	  ?>
	  </td>
	  <tr>
      <tr>

        <td height="21" valign="top" width="19%" align="left">Email ID<font color=red>* </font>:</td>
       
         <td> <input name="eid"  type="email">
        </td>
      </tr>
      <tr>
        <td valign="top"  height="21" valign="top" width="19%" align="left">Password<font color=red>*: </font></td>

        
	<td><input name="password" type="password" value="" id="email"></td>
      </tr>
      
      <tr>
        <td valign="top" align="left">&nbsp;</td>
        <td valign="top" align="left">
		<div style="padding-top:1px; float:left"><input type=submit name=submit value=login>&nbsp;<input type=reset value=reset></div>
		<div style="padding:5px 0px 0px 60px">	</td>

      </tr>
      </table>
      <center><a href="admin_login.php">Click Here To Login As Administartor.</a></center>
	  </td>
                <td style="background-image: url(&quot;right_line.gif&quot;); background-repeat: repeat-y; width: 10px;" valign="top" align="left">
<div style="background-image:url(stop_right.gif); background-position:top right; background-repeat:no-repeat; width:10px; height:19px"></div>				</td>
              </tr>
              
              <tr>
                <td style="background-image: url(&quot;bottom_left_.gif&quot;); background-position: right top; background-repeat: no-repeat; width: 10px; height: 11px;" valign="top" align="right"></td>
                <td style="background-image: url(&quot;bottom_line.gif&quot;); background-repeat: repeat-x; background-position: center top; height: 11px;"></td>

                <td style="background-image: url(&quot;bottom_right_.gif&quot;); background-position: right top; background-repeat: no-repeat; width: 10px; height: 11px;"></td>
              </tr>
        </tbody></table>	</td>
    <td class="text4" style="padding: 10px 30px 0px 20px;" valign="top" width="60%" align="left">
	<div style="width:100%" align="justify">
	<font color=red>New Customers</font> -<br> Register here to avail great benefits and receive<br> promotions and discounts that we offer our customers.
	<div class="clear3"></div>
	<br>Also next time, When you shop here, you just need <br>to Sign-In to finish your shopping process.
	<div class="clear4"></div>

	<div><br><a href="user_register.php"><input type=button name=submit value=sign_up></a></div>
		 </td>
  </tr>
   <tr>
    <td colspan="2" style="padding: 0px 0px 0px 20px; height: 20px;" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" style="padding: 0px 0px 0px 20px; height: 5px; background-color: rgb(242, 241, 241);" valign="bottom" align="center">	</td>

  </tr>
   <tr><td colspan="2"><div style="height:1px; border-bottom:#FFFFFF 2px solid"></div></td></tr>
  </tbody></table>
</form>


<?php include 'footer.php'; ?>

</body>

</html>
