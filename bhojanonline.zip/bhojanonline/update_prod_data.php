<?php
session_start();
if(isset($_SESSION["username"]) && $_SESSION["usertype"] == "admin")
{
}
else
{
	header('Location:admin_login.php');
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
background:black;
color: white;>
	       <html>
	       <head>
	       <title>Login</title>

	       <style type="text/css">

	       .colour{color: #F00}
       .color2{color: #003}
       .color1{color: #FFF}
       .text1{font-size:24px}
       .look{font-size:14px; color:#333}
       a{ text-decoration:none}

       .border1{border:none; color:#CCC}
       table.menu
       {

position: absolute;
visibility:hidden;
       }

}
</style>


	<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="hidden";
}
</script>
<script type="text/javascript">

<link href="js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js-image-slider.js" type="text/javascript"></script>
<link href="generic.css" rel="stylesheet" type="text/css" />
<link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</br>
<center><font size="6" color="#FFAB00"><h1>Product Deatails</h1></font></center>
<br>
<center>
<form method="POST" action="update_prod.php" enctype="multipart/form-data">
<center><h2>Please Replace The Details of the Product in there Respective Places.</h2></center>
</br>

   <script>
        var loadFile = function(event) {
        var output = document.getElementById('output');
        output.src = URL.createObjectURL(event.target.files[0]);
		output.value = URL.createObjectURL(event.target.files[0]);
         };
   </script>
   <img id="output" width='200px' height='200px'/>
 	 <?php
	 if(!empty($_GET['pid']))
	 {
	 $pid = $_GET['pid'];
	 $str = "pid='".$pid."'";
	 }
	 if(!empty($_GET['pname']))
	 {
	 $pname = $_GET['pname'];
	 $str = "pname='".$pname."'";
	 }
	 if(!empty($_GET['pid']) && !empty($_GET['pname']))
	 {
	 $pid = $_GET['pid'];
	 $pname = $_GET['pname'];
	 $str = "pid='".$pid."' pname='".$pname."'";
	 }
	 $product = $_GET['product'];
     $con=mysqli_connect("localhost","root","","bhojanonline");

     $query11=mysqli_query($con, "select * from ".$product." where ".$str);
	    while($row=mysqli_fetch_array($query11))
		{
          $pid = $row['pid'];
		  $pname = $row['pname'];
		  $category_id = $row['category_id'];
		  $price = $row['price'];
		  $image = $row['image'];
		}
	?> 
  <table>
   <tr>
   <td>Product PID  :</td>
   <td><input type=text name="pid" value="<?php echo $pid; ?>"></td>
  </tr>
  <tr>
   <td>Product Image  :</td>
   <td><input type=text name="image" value="<?php echo $image; ?>" id="output"><input type=file name="image" onchange="loadFile(event)" value="<?php echo $image; ?>"></td>
  </tr>
   <tr>
    <td>Product Category:</td>
	<td><select name="category_id" value="<?php echo $category_id; ?>">
	 <?php
      $query11=mysqli_query($con, "select * from category");
	    while($row=mysqli_fetch_array($query11))
		{
          echo "<option value='".$row['category_id']."'>".$row['category_name']."</option>";
		}
	?>
  </select>
	</td>
  </tr>
  <tr>
    <td>Product Name:</td>
	<td><input type=text name="pname" value="<?php echo $pname; ?>"></td>
  </tr>
    <tr>
    <td>Product Price:</td>
	<td><input type=text name="price" value="<?php echo $price; ?>"></td>
  </tr>
   <tr>    
    <td><input type="submit" name="submit" value="Update"></td>
	<td><input type="reset" value="Reset"></td>
   </tr>
</table>   
</form>
</center>
<br>
<?php
if(!empty($_GET['msg']))
{
	echo "<font color='green'>".$_GET['msg']."</font>";
}
?>
<br>   
<center><a href="update_prod_search.php"><img src="foodimage/goback1.jpg"></img></a></center>
<?php include "footer.php"; ?>
</body>
</html>
