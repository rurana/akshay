<SCRIPT LANGUAGE=javascript>
function checkEmail(eid) {
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(eid)){
		return (true)
		}
		alert("Invalid E-mail Address! Please re-enter.")
		return (false);
	}
}

function validateForm(formObj)/*{
   //TO DO Add Java Script Validation Code Here
  
   if(formObj.fname.value.length==0){
		alert("Please enter User Id!");
		formObj.fname.focus();
		return false;
   }*/

    if(formObj.password.value.length==0){
		alert("Please enter Password!");
		formObj.password.focus();
		return false;
   }

    if(formObj.fname.value.length==0){
		alert("Please enter First Name!");
		formObj.fname.focus();
		return false;
   }


    if(formObj.lname.value.length==0){
		alert("Please enter Last Name!");
		formObj.lname.focus();
		return false;
   }

   if(formObj.eid.value.length==0){
		alert("Please enter Email!");
		formObj.eid.focus();
		return false;
   }


   if(!checkEmail(formObj.email.value)){
		   formObj.email.focus();
		   return false;
	   }

   if(formObj.city.value.length==0){
		alert("Please enter Country!");
		formObj.city.focus();
		return false;
   }
  

  if(formObj.pincode.value.length==0){
		alert("Please enter zip!");
		formObj.pincode.focus();
		return false;
   }

   if(isNaN(formObj.pincode.value)){
		alert("Please enter correct Zip Code!");
		formObj.pincode.focus();
		return false;
   }

    if(formObj.state.value.length==0){
		alert("Please enter State!");
		formObj.state.focus();
		return false;
   }

 if(formObj.city.value.length==0){
		alert("Please enter City!");
		formObj.city.focus();
		return false;
   }
    if(formObj.address.value.length==0){
		alert("Please enter Address!");
		formObj.address.focus();
		return false;
   }
 

    if(formObj.phone.value.length==0){
		alert("Please enter Phone!");
		formObj.phone.focus();
		return false;
   }

   if(isNaN(formObj.phone.value)){
		alert("Please enter correct Phone No.!");
		formObj.phone.focus();
		return false;
   }

    if(formObj.fax.value.length==0){
		alert("Please enter Fax!");
		formObj.fax.focus();
		return false;
   }

   if(isNaN(formObj.fax.value)){
		alert("Please enter correct Fax No.!");
		formObj.fax.focus();
		return false;
   }

    

   formObj.actionUpdateData.value="submit";
   return true;
}
function allFilled() {
	var fname = document.getElementById("fname").value;
	var lname = document.getElementById("lname").value;
	var eid = document.getElementById("eid").value;
	var address= document.getElementById("address").value;
	var state = document.getElementById("state").value;
	var city = document.getElementById("city").value;
	var pincode = document.getElementById("pincode").value;
	var phone = document.getElementById("phone").value;
	var m = document.getElementById("m").value;
	var password = document.getElementById("password").value;
	var cpassword= document.getElementById("cpassword").value;
 if (fname.length == 0 || lname.length == 0|| eid.length==0 || address.length==0 || state.length==0 || city.length==0 || pincode.length==0 || phone.length==0 || m.length==0 || password.length==0 || cpassword.length==0)
    {
        alert("please fill all fields");
	return false;
        
    }
return true;
  

}
</SCRIPT>


<?php
session_start();
/*$_SESSION['fname']=$_POST['fname'];
$_SESSION['m']=$_POST['m'];
$_SESSION['address']=$_POST['address'];*/
//include('register.js');
$con=mysqli_connect("localhost","root","","bhojanonline");
if(!$con)
{
	alert('not conneted');
}
if(isset($_POST['submit']))
{
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$eid=$_POST['eid'];
$address=$_POST['address'];
$state=$_POST['state'];
$city=$_POST['city'];
$pincode=$_POST['pincode'];
$phone=$_POST['phone'];
$m=$_POST['m'];
$password=$_POST['password'];
$cpassword=$_POST['cpassword'];

function checkmail($eid)
			{
					if(ereg("^[_a-z 0-9-]+(\.[_a-z0-9-] *@[a-z0-9-]+\.[a-z0-9-]+)+$",$eid))
					{
							return 1;
					}
					else
							return 0;
		}
/*
		if(!checkmail($eid))
		{
				echo "In valid email address..............";
		}
		else
		{
				echo "Email address is valid.............";
		}
}*/		
$sql="insert into user_info values('$fname','$lname','$eid','$address','$state','$city','$pincode','$phone','$m','$password','$cpassword')";
/*
if(mysql_query($sql))
{
	
  header('Location:login.html');
}
else
{
	echo "your registration is failed... please try again!!!";

     
	echo" <a href='register.html'><input type=submit value=back></a>";
	 
	 header('Location:register.html');
}

*/
if(mysqli_query($con,$sql))
{
	$sql="insert into login values('$eid','$password')";
	mysqli_query($con, $sql);
	
	echo "<h1><i> Welcome to BhojanOnline.com...<br>you have been registered successfully,now you can login to our website for quick meals on wheels...</i></h1>";
	echo "<h2>Click here to Login...</h2>";
	 
	echo "<a href='user_login.php'><img src=login5.jpg></img></a>";

	//header("Location:user_login.php");
}
else
{
	echo "your registration is failed... please try again!!!";

     
	 echo"<a href='user_register.php'><input type=submit value=back></a>";
	 
	// header('Location:user_register.php');
}
}
mysqli_close($con);

?>
