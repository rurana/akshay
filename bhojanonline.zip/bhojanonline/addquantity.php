<?php
session_start();
$quantity = $_GET['q'];
$name = $_GET['n'];
$item = $_GET['i'];
echo  $quantity." ".$name." ".$item;
$new_product['product_code'] = $name;
$new_product['product_quantity'] = $quantity + 1 ;
unset($_SESSION['cart_item'][$name]);
$_SESSION['cart_item'][$new_product['product_code']][$new_product['product_quantity']] = $item;
header("location:cart.php");
?>