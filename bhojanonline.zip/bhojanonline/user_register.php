<!DOCTYPE html>
<html>
<head>
<title>Registration</title>
<style type="text/css">
.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}
.border1{border:none; color:#CCC}
table.menu
{
position: absolute;
visibility:hidden;
}
</style>
<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>
<script>
function validate()
	{
		function isAlpha(argvalue) 
        	{
  			argvalue = argvalue.toString();
  			var validChars = " +-abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    			for (var n = 0; n < argvalue.length; n++) 
    			{
        			if (validChars.indexOf(argvalue.substring(n, n+1)) == -1)
         			return false;
    			}
	
		}
		
		function ValidateEmail(eid)  
		{  	
			eid =eid.toString();
  			
			var mailformat =" /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/";  
			if(eid.value.match(mailformat))  
			{	  
				return true;  
			}  
			else  
			{  
				alert("You have entered an invalid email address!");  
				document.form1.eid.focus();  
				return false;  
			}  
		}  
		
	var mail=document.form1.eid.value;
		if (mail.length=="") 
		{
  			alert("You must enter valid email id.");
  			document.form1.eid.focus();
  			return false;
 		}
 		/*else if(ValidateEmail(mail)==false)
 		 {
   			alert("Enter only alphabates!")
  			document.form1.eid.focus();
   			return false;
  		}
*/
 		/*
 	var email="/^\w(\.?[\w-])*@\w(\.?[\w-])*\.[a-z]{2,6}(\.[a-z]{2})?$/";
		if(eid.value.match(email))  
		{  
			return true;  
		}
		else
		{
		alert("pls enter valid email address ");
		document.form1.eid.focus();
		return false;
		}	
      	
*/
 	var a=document.form1.fname.value;
		
  		if(a=="")
  		{
    			alert("Please enter Username!")
    			document.form1.fname.focus();
    			return false;
  		}
 		
		if ((a.length<3) || (a.length>20))
		{
			alert("Your Character must be 3 to 20 Character!");
			document.form1.fname.focus();
			return false;
		}
	var dValidate1=document.form1.lname.value;
		
  		if(dValidate1=="")
  		{
    			alert("Please enter Last Name!")
    			document.form1.lname.focus();
    			return false;
  		}
 		 else if(isAlpha(dValidate1)==false)
 		 {
   			alert("Enter only alphabates!")
  			document.form1.lname.focus();
   			return false;
  		}
		if ((dValidate1.length < 3) || (dValidate1.length > 20))
		
		{
			alert("Your name must be 3 to 20 Character!");
			document.form1.lname.focus();
			return false;
		}
		
	var addr=document.form1.address.value;
		
  		if(addr=="")
  		{
    			alert("Please enter address!")
    			document.form1.address.focus();
    			return false;
  		}
  		
        var t=document.form1.city.value;
		
  		if(t=="")
  		{
    			alert("Please enter city!")
    			document.form1.city.focus();
    			return false;
  		}
  	  var pin = document.form1.pincode.value;
		if(pin=="")
		{
			alert("please Enter the pincode Number");
			document.form1.pincode.focus();
			return false;
		}
		if(isNaN(pin))
		{
			alert("Enter the valid pincode Number(Like : 411018)");
			document.form1.pincode.focus();
			return false;
		}
		if(pin.length!=06)
		{
			alert(" Please enter correct pincode number");
			document.form1.pincode.select();
			return false;
		}
	
  	var ph = document.form1.phone.value;
		if(ph=="")
		{
			alert("please Enter the phone Number");
			document.form1.phone.focus();
			return false;
		}
		if(isNaN(ph))
		{
			alert("Enter the valid phone Number(Like : 27489657)");
			document.form1.phone.focus();
			return false;
		}
		if(ph.length!=8)
		{
			alert(" Please enter correct 8 digit phone number");
			document.form1.phone.select();
			return false;
		}
	
	var dValidate2 = document.form1.m.value;
		if(dValidate2=="")
		{
			alert("please Enter the mobile Number");
			document.form1.m.focus();
			return false;
		}
		if(isNaN(dValidate2))
		{
			alert("Enter the valid Mobile Number(Like : 8956633704)");
			document.form1.m.focus();
			return false;
		}
		if(dValidate2.length!=10)
		{
			alert(" Please enter correct contact number");
			document.form1.m.select();
			return false;
		}

	var b=document.form1.password.value;
		
  		if(b=="")
  		{
    			alert("Please enter Password!")
    			document.form1.password.focus();
    			return false;
  		}
 		
		if ((b.length < 6) || (b.length > 15))
		{
			alert("Password must be 6 to 15 Character!");
			document.form1.password.focus();
			return false;
		}
	var c=document.form1.cpassword.value;
		if(c=="")
  		{
    			alert("Please Re-enter Password!")
    			document.form1.cpassword.focus();
    			return false;
  		}
  		if(c!==b)
  		{
  			alert("mismatch password,plz try again...!");
  			document.form1.cpassword.focus();
    			return false;
    		}	
	
	}
</script>
<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>

<p><b><h3><blink><font color=red>
New Customers!</font></blink></h3></b> <h3>Register now to access the best bargain and an unmatched online food shopping experience. Its Easy, Fast and Free.</p>
<p>
Already Registered ?<a href="user_login.php"> Sign In</a></p>

<p>Please note that the address below is also is your billing address.</p>
<p>Fields Marked with an asterik (<font color=red>*</font>) are mandatory.</p>
<br>
 
<center>
 <form method=post name="form1"  action="register.php" onsubmit="return validate();">
<table cellpadding="5" cellspacing="5">
<tr>
	<td><font color=red>*</font>Email-id</td> <td>:</td><td><input type="text" name="eid" size=25 required></td>
</tr>
<tr>
	<td><font color=red>*</font>First Name</td> <td>:</td> <td><input type=text name="fname" size=25 required></td>
</tr>
<tr>
	<td>&nbsp;Last Name</td>  <td>:</td><td><input type=text name="lname" size=25></td>
</tr>
<tr>
	<td><font color=red>*</font>Address</td><td>:</td> <td><textarea name="address" rows=10 cols=27 required></textarea></td> 
                   <td>
		<table>
			<tr>
			<td><font color=red>*</font>State</td> <td>:</td> <td><select name="state" required> <option selected="selected" value="0">Select State</option>
              <option value="29">Andaman and Nicobar Islands</option><option value="1">Andra Pradesh</option><option value="2">Arunachal Pradesh</option><option value="3">Assam</option><option value="4">Bihar</option><option value="30">Chandigarh</option><option value="5">Chhattisgarh</option><option value="31">Dadar and Nagar Haveli</option><option value="32">Daman and Diu</option><option value="33">Delhi</option><option value="6">Goa</option><option value="7">Gujarat</option><option value="8">Haryana</option><option value="9">Himachal Pradesh</option><option value="10">Jammu and Kashmir</option><option value="11">Jharkhand</option><option value="12">Karnataka</option><option value="13">Kerala</option><option value="34">Lakshadeep</option><option value="14">Madya Pradesh</option><option value="15">Maharashtra</option><option value="16">Manipur</option><option value="17">Meghalaya</option><option value="18">Mizoram</option><option value="19">Nagaland</option><option value="20">Orissa</option><option value="36">Other</option><option value="35">Pondicherry</option><option value="21">Punjab</option><option value="22">Rajasthan</option><option value="23">Sikkim</option><option value="24">Tamil Nadu</option><option value="25">Tripura</option><option value="27">Uttar Pradesh</option><option value="26">Uttaranchal</option><option value="28">West Bengal</option>		    <option value="36">Other</option></select></td>

			</tr>

			<tr>

                                			<td><font color=red>*</font>City</td><td>:</td><td><input type=text name="city" size=25 required></td>
			</tr>

                                                      <tr>
				<td><font color=red>*</font>Pin Code</td><td>:</td><td><input type=text name="pincode" size=25 required></td>
			</tr>
			
			
		</table>
                   </td>
</tr>



<tr><td><font color=red></font>Phone</td> <td>:</td> <td><input type=text name="phone" size=25></td></tr>
<tr><td><font color=red></font>Mobile</td> <td>:</td> <td><input type=text name="m" size=25></td></tr>

<tr><td colspan=5><hr></td></tr>
<tr><td><font color=red>*</font>Password</td> <td>:</td> <td><input type=password name="password" size=25 required></td></tr>
<tr><td></td><td></td><td><font color=red>(minimum 6 characters please)</font></td></tr>

<tr><td><font color=red>*</font>Confirm Password</td>  <td>:</td><td><input type=password name="cpassword" size=25 required></td></tr>
<tr><td colspan=5><hr></td></tr>

</table>

<br><br>
<table>
<tr>
	<input type=submit name=submit value="" style="background-image:url(foodimage/submit.jpg);width:95px; height:24px; border-width:0px; padding:0px">
<input type=reset name=reset value="" style="background-image:url(foodimage/reset.jpg);width:85px; height:24px; border-width:0px; padding:0px">
	
	</tr>
</table>
</form>
<?php include "footer.php"; ?>
</body>
</html>
