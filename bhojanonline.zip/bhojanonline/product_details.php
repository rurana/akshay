<?php
session_start();
if(isset($_SESSION["username"]))
{
}
else
{
	header('Location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>BhojanOnline.com</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}
</style>
<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>
<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>
<?php include 'header.php'; ?>
</br>
<center>
<b><strong>Bill Detail Items Are Below:</strong></b>
<?php

$details = $_GET['d'];
$product = explode("@", $details);
echo "<table border='1' align='center'>";
echo "<tr><th>Sr No.</th><th>PRODUCT NAME</th><th> PRICE</th><th>QUANTITY</th><th>TOTAL</th></tr>";
foreach($product as $item)
{ 
 $entry = explode(":", $item);
 echo "<tr>";
 foreach($entry as $item2)
{
	echo "<td>".$item2."</td>";
}
 echo "</tr>";
}
echo "</table>";
?>
</center>
<?php if($_SESSION['usertype'] == "user"){?>
<center><a href="user_bill_info.php"><img src="foodimage/goback1.jpg"></img></a></center>
<?php } else { ?>
<center><a href="user_bill_admin.php"><img src="foodimage/goback1.jpg"></img></a></center>
<?php } ?>
<?php include 'footer.php'; ?>
 </body>
</html>