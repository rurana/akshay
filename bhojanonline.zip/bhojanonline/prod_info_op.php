<?php
session_start();
if(isset($_SESSION["username"]) && $_SESSION["usertype"] == "admin")
{
}
else
{
	header('Location:admin_login.php');
}
?>
<!DOCTYPE html      a:hover{color: #3FF}
#menu1 td:hover{
background:black;
color: white;>
	       <html>
	       <head>
	       <title>Login</title>

	       <style type="text/css">

	       .colour{color: #F00}
       .color2{color: #003}
       .color1{color: #FFF}
       .text1{font-size:24px}
       .look{font-size:14px; color:#333}
       a{ text-decoration:none}

       .border1{border:none; color:#CCC}
       table.menu
       {

position: absolute;
visibility:hidden;
       }

}
</style>


	<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
	document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js-image-slider.js" type="text/javascript"></script>
<link href="generic.css" rel="stylesheet" type="text/css" />
<link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</br>
<center><font size="6" color="#FFAB00"><h2>***PRODUCT REPORT***<h2></font></center>
</br>
<center><table>
<tr><td><a href="prod_info.php"><img src="foodimage/info2.jpg"></img></a></td> 
<td><font size="4" ><h3>PRODUCT INFORMATION<h3></font></td></tr><tr></tr><tr></tr>
<tr><td><a href="add_prod_reg.php"><img src="foodimage/add.jpg"></img></a></td> 
<td><font size="4" ><h3>INSERT PRODUCT<h3></font></td></tr><tr></tr><tr></tr>
<tr><td><a href="update_prod_search.php"><img src="foodimage/update11.jpg"></img></a> </td> 
<td><font size="4" ><h3>UPDATE PRODUCT INFORMATION<h3></font></td></tr><tr></tr><tr></tr>
<tr><td><a href="remove_search.php"><img src="foodimage/delete2.jpg"></img></a></td> 
<td><font size="4" ><h3>DELETE PRODUCT</h3></font></td></tr><tr></tr><tr></tr>
<tr><td><a href="report.php"><img src="foodimage/goback1.jpg"></img></a></td> 
<td><font size="4" ><h3>Admin Panel</h3></font></td></tr><tr></tr><tr></tr>
</table></center>
<?php include "footer.php"; ?>
</body></html>
