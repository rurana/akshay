<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>GET MY FOOD ONLINE</title>

<style type="text/css">

.colour{color: #F01}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<?php include "header.php"; ?>
</br>
<blink><h1><font color="GREEN" face="Times New Roman, Times, serif"><center>WELCOME TO GET MY FOOD ONLINE</center></font></h1></blink>
	<br>
    <div id="sliderFrame">
        <div id="slider">
		    <img src="foodimage/black1.jpg" width="100%" height="100%"/>    
            <img src="foodimage/123.jpg" width="100%" height="100%"/>
            <img src="foodimage/burger1.jpeg"  width="100%" height="100%"/>
            <img src="foodimage/veg_roll.jpg" width="100%" height="100%"/>		
        </div>
        <!--thumbnails-->
        <div id="thumbs">
            <div class="thumb">
                <div class="frame"><img src="foodimage/black1.jpg" /></div>
                <div class="thumb-content"><p>Cake's</p></div>
                <div style="clear:both;"></div>
            </div>
            <div class="thumb">
                <div class="frame"><img src="foodimage/123.jpg" /></div>
                <div class="thumb-content"><p>Pizzas</p></div>
                <div style="clear:both;"></div>
            </div>
            <div class="thumb">
                <div class="frame"><img src="foodimage/burger1.jpeg" /></div>
                <div class="thumb-content"><p>Burger's</p></div>
                <div style="clear:both;"></div>
            </div>
            <div class="thumb">
                <div class="frame"><img src="foodimage/veg_roll.jpg" /></div>
                <div class="thumb-content"><p>Roll's</p></div>
                <div style="clear:both;"></div>
            </div>
	    </div>

        <!--clear above float:left elements-->
        <div style="clear:both;height:0;"></div>
    </div>
	</br>
	<div class="phead1"><center>GET MY FOOD ONLINE CATEGORY</center></div>	
	<marquee  onmouseover="this.stop();" onmouseout="this.start();">
	<table cellpadding="5" cellspacing="5">
	<tr>
	
    <?php 

    $con=mysqli_connect("localhost","root","","bhojanonline");

    if(!$con)
    {
	alert('not conneted');
    }

    $query2=mysqli_query($con,"select * from category");
    while($row=mysqli_fetch_array($query2))
    {
     echo "<td width='16%'><a HREF=product.php?id=".$row['category_name']."><img src=".$row['image']." width='200' height='150'></a></td>";
     echo "<td width='13%' align='left'><a HREF=product.php?id=".$row['category_name']."><b><font size=5>".ucwords(strtolower($row['category_name']))."</font></a></td>";
    }
    ?>
	
	</tr>
	</table>
	</marquee>
	<div class="phead1"><center>Please Select From Our Menu</center></div>
<br><b><center>Welcome to get my food online we serve fresh food to our customer so we never let you down.You just nead select food items from our website and we will deliver to you as soon as posibile.</br> WORKING HARD IS OUR PASSION :)</center></b>
<?php include "footer.php"; ?>
</body>
</html>

