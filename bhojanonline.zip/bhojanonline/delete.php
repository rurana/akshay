<!DOCTYPE html>
<html>
<head>
    <title>BhojanOnline.com</title>

<style type="text/css">

.colour{color: #F00}
.color2{color: #003}
.color1{color: #FFF}
.text1{font-size:24px}
.look{font-size:14px; color:#333}
a{ color: #03F;text-decoration:none}

.border1{border:none; color:#CCC}
table.menu
{

position: absolute;
visibility:hidden;
}

</style>


<script type="text/javascript">
function co()
{
	document.bgColor="#f30"
}
function showmenu(elmnt)
{
document.getElementById(elmnt).style.visibility="visible";
}
function hidemenu(elmnt)
{
document.getElementById(elmnt).style.visibility="hidden";
}
</script>

<link href="themes/2/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/2/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link href="head.css" rel="stylesheet" type="text/css" />

</head>
<body>

<!-- HEADER -->
<table class="head" border="0"><tr><td></td></tr></table>
	<br>
	<div>
		<table width="100%" border="0">
			<tr>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<img src="d1.jpg" height="45px" width="260px"></img><br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
					<b class="mydes">BhojanOnline.com...</b>
				</td>
				
				<td align=center>
				<img src="images/Sports.jpg" height=100 width=200>	</img>
				</td>
                <td align="right">
           			<a href="home_body.html" ><img src="logout.jpg"></img></a>&nbsp;&nbsp;&nbsp;
				</td>
				
			</tr>

		</table>
	</div>

<br>
<div id="menu1">
	<table width="100%" border="0">
		  <tr bgcolor="#666666">
				
				<td align="center"  height="40"><a href="home_body.html" class="color1" ><b style="color:#FFF">Home</b></a></td>
    				
				<td scope="col" id="mobile" onMouseOver="showmenu('abtmob')"  onMouseOut="hidemenu('abtmob')" align="center"><b style="color:#FFF">About Us</b>
    					<table class="menu" width="120" id="abtmob" border="0"  bgcolor="#CCCCCC">
 				 		<tr>
    							<td class="menu"><a  href="what_we_are.html" ><b>What We Are?</b></a></td>
  						</tr>
 					      <tr>
 							<td class="menu"><a href="terms_conditions.html" ><b>Terms & Condition</b></a></td>
  						</tr>
					</table>

   				 </td>

				<td scope="col" id="mobile" onMouseOver="showmenu('abtmob1')"  onMouseOut="hidemenu('abtmob1')" align="center"><b style="color:#FFF">Product</b>
    			<table class="menu" width="120" id="abtmob1" border="0"  bgcolor="#CCCCCC">
 			<tr>
    			<td class="menu"><a  href="salad.html" ><b>Salads</b></a></td>
  			</tr>
 					      <tr>
 							<td class="menu"><a href="starter.html" ><b>starters</b></a></td>
  						</tr>
  						<tr>
    			<td class="menu"><a  href="roti.html" ><b>Roti's</b></a></td>
  			</tr>
  			<tr>
    			<td class="menu"><a  href="sabji.html" ><b>Sabji's</b></a></td>
  			</tr>
  			<tr>
    			<td class="menu"><a  href="pulav.html" ><b>pulav's</b></a></td>
  			</tr>



					</table>

   				 </td>




<td scope="col" align="center" onMouseOver="showmenu('abtelec1')" onMouseOut="hidemenu('abtelec1')"><b style="color:#FFF">Shopping With Us</b>

    <table width="200" bgcolor="#CCCCCC" border="0" class="menu" id="abtelec1">
  <tr>
    <td class="menu"><a href="Payment_option.html"><b>Payment options</b></a></td>
  </tr>

  <tr>
    <td class="menu"><a href="Payment_instruction.html"  ><b>Payment Instructions</b></a></td>
  </tr>

<tr>
    <td class="menu"><a href="Cancellation_policy.html"  ><b>Cancellation Policy</b></a></td>
  </tr>
 </table>
 </td>





 <td scope="col" align="center" onMouseOver="showmenu('abtelec')" onMouseOut="hidemenu('abtelec')"><b style="color:#FFF">My  Account</b>

    <table width="200" bgcolor="#CCCCCC" border="0" class="menu" id="abtelec">
  <tr>
    <td class="menu"><a href="login.html" ><b>sign in</b></a></td>
  </tr>

  <tr>
    <td class="menu"><a href="register.html" ><b>Register with us</b></a></td>
  </tr>
 </table>
 </td>



				<td align="center"  height="40"><a href="feedback.html" class="color1" ><b style="color:#FFF">Feedback</b></a></td>

				<td align="center"  height="40"><a href="contac_us.html" class="color1" ><b style="color:#FFF">Contact Us</b></a></td>


	</table>
	<br>
	<br>
	<br>
    
<center> <h1>You can select corresponding checkbox If you want to cancel that perticular items. </h1></center>
   <br>
   <br>
  <center> 
  <form method=post action="remove2.php">
<?php

$con=mysql_connect("localhost","root","");
mysql_select_db("bhojanonline",$con);

        $query1=mysql_query("select * from cart");
	                                       
		
		//$cnt=1;
		echo "<table border=1><tr><th>Product ID</th><th>Product Name</th><th>Price</th><th>Mark</th></tr>";
		while($row=mysql_fetch_array($query1))
		{
			
			echo "<tr><td>".$row['pid']."</td><td>".$row['pname']."</td><td>".$row['price']."</td>";
			echo "<td><input type=checkbox name=prod[] value=".$row['pid']."></td></tr>";
				
		}
		echo "</table>";
mysql_close($con)
?>
    <br><br>
    <input type=submit value="Remove">
   </center>
  </form>  
</body>
</html>
