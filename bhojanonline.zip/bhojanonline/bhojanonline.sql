-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2017 at 06:17 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bhojanonline`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `bno` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `total` float DEFAULT NULL,
  `date` date DEFAULT NULL,
  `product_details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bno`, `email`, `fname`, `mobile`, `address`, `total`, `date`, `product_details`) VALUES
(8, 'admin', 'vghh', 'hfh', 'fghf', 100, '2017-04-15', '@1:Veg Sandwich:25:1:25@2:Veg Ham Burger:25:3:75'),
(9, 'admin', 'Rahul', '9762569986', 'nehru nagar', 145, '2017-04-15', '@1:Veg Crispy:70:1:70@2:Mirchi Pakoda:75:1:75');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(45) DEFAULT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `image`) VALUES
(1, 'snacks', 'foodimage/sn5.jpg'),
(2, 'salads', 'foodimage/sal2.jpg'),
(3, 'starters', 'foodimage/21.jpg'),
(4, 'roti', 'foodimage/ro_3.jpg'),
(5, 'sabji', 'foodimage/32.jpg'),
(6, 'pulav', 'foodimage/pul3.bmp'),
(7, 'deserts', 'foodimage/de8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `deserts`
--

CREATE TABLE `deserts` (
  `pid` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `pname` varchar(60) NOT NULL,
  `price` varchar(40) NOT NULL,
  `image` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deserts`
--

INSERT INTO `deserts` (`pid`, `category_id`, `pname`, `price`, `image`) VALUES
(1, 7, 'Gajar Halwa', '70', 'foodimage/de1.jpg'),
(2, 7, 'Gulab Jamun', '120', 'foodimage/de2.jpg'),
(3, 7, 'Jalebi', '80', 'foodimage/de3.jpg'),
(4, 7, 'Kaju Katli', '110', 'foodimage/de4.jpg'),
(5, 7, 'Kesar Roll', '130', 'foodimage/de5.jpg'),
(6, 7, 'Kheer', '60', 'foodimage/de6.jpg'),
(7, 7, 'Mango Faluda', '60', 'foodimage/de7.jpg'),
(8, 7, 'Ras Malai', '110', 'foodimage/de8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `fname` varchar(40) NOT NULL,
  `emid` varchar(40) NOT NULL,
  `address` varchar(40) DEFAULT NULL,
  `mobile` varchar(40) NOT NULL,
  `msg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `eid` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`eid`, `password`) VALUES
('rahul@gmail.com', 'rahul123');

-- --------------------------------------------------------

--
-- Table structure for table `pulav`
--

CREATE TABLE `pulav` (
  `pid` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `pname` varchar(60) NOT NULL,
  `price` varchar(40) NOT NULL,
  `image` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pulav`
--

INSERT INTO `pulav` (`pid`, `category_id`, `pname`, `price`, `image`) VALUES
(1, 6, 'Plain Rice', '70', 'foodimage/79.jpg'),
(2, 6, 'Veg Biryani', '120', 'foodimage/90b.jpg'),
(3, 6, 'Kashmiri Pulav', '125', 'foodimage/91b.jpg'),
(4, 6, 'Mutter Pulav', '110', 'foodimage/92b.jpg'),
(5, 6, 'Paneer Pulav', '70', 'foodimage/pul1.bmp'),
(6, 6, 'Tava Pulav', '80', 'foodimage/pul2.bmp'),
(7, 6, 'Panir Biryani', '125', 'foodimage/pul3.bmp'),
(8, 6, 'Jeera Rice', '90', 'foodimage/pul4.bmp');

-- --------------------------------------------------------

--
-- Table structure for table `roti`
--

CREATE TABLE `roti` (
  `pid` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `pname` varchar(60) NOT NULL,
  `price` varchar(40) NOT NULL,
  `image` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roti`
--

INSERT INTO `roti` (`pid`, `category_id`, `pname`, `price`, `image`) VALUES
(1, 4, 'Butter Paratha', '15', 'foodimage/ro_1.jpg'),
(2, 4, 'Jowar Roti', '10', 'foodimage/ro7.jpg'),
(3, 4, 'Butter Roti', '8', 'foodimage/ro_3.jpg'),
(4, 4, 'Chapati', '10', 'foodimage/ro_4.jpg'),
(5, 4, 'Naan', '25', 'foodimage/ro8.jpg'),
(6, 4, 'Bajra Roti', '10', 'foodimage/ro10.jpg'),
(7, 4, 'Onion Kulcha', '15', 'foodimage/ro11.jpg'),
(8, 4, 'Tandoori Roti', '15', 'foodimage/ro9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sabji`
--

CREATE TABLE `sabji` (
  `pid` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `pname` varchar(60) NOT NULL,
  `price` varchar(40) NOT NULL,
  `image` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sabji`
--

INSERT INTO `sabji` (`pid`, `category_id`, `pname`, `price`, `image`) VALUES
(1, 5, 'Butter Masala', '110', 'foodimage/31.jpg'),
(2, 5, 'Veg Curry', '130', 'foodimage/32.jpg'),
(3, 5, 'Masala Curry', '90', 'foodimage/37b.jpg'),
(4, 5, 'Veg Kofta', '120', 'foodimage/40.jpg'),
(5, 5, 'Veg Hydrabadi', '180', 'foodimage/40b.jpg'),
(6, 5, 'Veg Bhuna', '110', 'foodimage/43b.jpg'),
(7, 5, 'Veg Maratha', '130', 'foodimage/46b.jpg'),
(8, 5, 'Paneer Butter Masala', '120', 'foodimage/48.jpg'),
(9, 5, 'Mutter Paneer', '125', 'foodimage/49b.jpg'),
(10, 5, 'Veg Kolhapuri', '110', 'foodimage/52b.jpg'),
(11, 5, 'Chole Masala', '100', 'foodimage/71b.jpg'),
(12, 5, 'Bhojans Special', '120', 'foodimage/72b.jpg'),
(13, 5, 'Aloo Palak', '60', 'foodimage/sab1.jpg'),
(14, 5, 'Baingan Bharta', '75', 'foodimage/sab2.jpg'),
(15, 5, 'Veg Jalfrezi', '130', 'foodimage/sab3.jpg'),
(16, 5, 'Veg Korma', '120', 'foodimage/sab4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `salads`
--

CREATE TABLE `salads` (
  `pid` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `pname` varchar(60) NOT NULL,
  `price` varchar(40) NOT NULL,
  `image` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salads`
--

INSERT INTO `salads` (`pid`, `category_id`, `pname`, `price`, `image`) VALUES
(1, 2, 'Veg Salad', '50', 'foodimage/sa1.jpg'),
(2, 2, 'Fruit Salad', '50', 'foodimage/Sa2.jpg'),
(3, 2, 'Corn Salad', '35', 'foodimage/1a.jpg'),
(4, 2, 'Green Salad', '40', 'foodimage/67b.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `snacks`
--

CREATE TABLE `snacks` (
  `pid` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `pname` varchar(60) NOT NULL,
  `price` varchar(40) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `snacks`
--

INSERT INTO `snacks` (`pid`, `category_id`, `pname`, `price`, `image`) VALUES
(2, 1, 'Veg Ham Burger', '25', 'foodimage/sn2.jpg'),
(3, 1, 'Bread Pakoda', '15', 'foodimage/sn3.jpg'),
(4, 1, 'Pav Bhaji', '50', 'foodimage/sn4.jpg'),
(5, 1, 'Veg Sandwich', '25', 'foodimage/sn5.jpg'),
(6, 1, 'Cheese Sandwich', '40', 'foodimage/sn6.jpg'),
(7, 1, 'Idlli Sambar', '35', 'foodimage/sn7.jpg'),
(8, 1, 'Masala Dhosa', '50', 'foodimage/sn8.jpg'),
(16, 1, 'Samosa', '15', 'foodimage/sn1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `starters`
--

CREATE TABLE `starters` (
  `pid` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `pname` varchar(60) NOT NULL,
  `price` varchar(40) NOT NULL,
  `image` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `starters`
--

INSERT INTO `starters` (`pid`, `category_id`, `pname`, `price`, `image`) VALUES
(1, 3, 'Veg Crispy', '70', 'foodimage/4a.jpg'),
(3, 3, 'Mirchi Pakoda', '75', 'foodimage/10b.jpg'),
(4, 3, 'Masala Papad', '30', 'foodimage/12b.jpg'),
(5, 3, 'Paneer Pakoda', '90', 'foodimage/14b.jpg'),
(6, 3, 'Veg Spring Roll', '120', 'foodimage/16.jpg'),
(7, 3, 'Veg Manchurian', '130', 'foodimage/21.jpg'),
(8, 3, 'Palak Pakoda', '110', 'foodimage/23.jpg'),
(9, 3, 'Veg Kabab', '100', 'foodimage/23b.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `eid` varchar(30) NOT NULL,
  `address` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `pincode` int(6) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `m` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `cpassword` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`fname`, `lname`, `eid`, `address`, `state`, `city`, `pincode`, `phone`, `m`, `password`, `cpassword`) VALUES
('Rahul', 'Singh', 'rahul@gmail.com', 'Nehru Nagar', 'Mahrashtra', 'Pune', 411018, '02027442', '9762569986', 'rahul123', 'rahul123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`bno`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `deserts`
--
ALTER TABLE `deserts`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`emid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `pulav`
--
ALTER TABLE `pulav`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `roti`
--
ALTER TABLE `roti`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `sabji`
--
ALTER TABLE `sabji`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `salads`
--
ALTER TABLE `salads`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `snacks`
--
ALTER TABLE `snacks`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `starters`
--
ALTER TABLE `starters`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`eid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `bno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `deserts`
--
ALTER TABLE `deserts`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `pulav`
--
ALTER TABLE `pulav`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `roti`
--
ALTER TABLE `roti`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `sabji`
--
ALTER TABLE `sabji`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `salads`
--
ALTER TABLE `salads`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `snacks`
--
ALTER TABLE `snacks`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `starters`
--
ALTER TABLE `starters`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `deserts`
--
ALTER TABLE `deserts`
  ADD CONSTRAINT `deserts_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `pulav`
--
ALTER TABLE `pulav`
  ADD CONSTRAINT `pulav_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `roti`
--
ALTER TABLE `roti`
  ADD CONSTRAINT `roti_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `sabji`
--
ALTER TABLE `sabji`
  ADD CONSTRAINT `sabji_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `salads`
--
ALTER TABLE `salads`
  ADD CONSTRAINT `salads_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `snacks`
--
ALTER TABLE `snacks`
  ADD CONSTRAINT `snacks_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `starters`
--
ALTER TABLE `starters`
  ADD CONSTRAINT `starters_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
