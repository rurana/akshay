<!-- HEADER -->
<table class="head" border="0"><tr><td></td></tr></table>
	<br>
	<div>
		<table width="100%" border="0">
			<tr>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<img src="foodimage/k1.jpg" height="45px" width="260px"></img><br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
					<b class="mydes">BHOJAN ONLINE...</b>
				</td>
				
				<td align=center>
				<img src="foodimage/Dough-Boy.jpg" height=100>	</img>
				</td>
				<td align="right">
				<?php if(isset($_SESSION["username"])) { ?>
           			<a href="logout.php" ><img src="foodimage/logout.jpg"></img></a>&nbsp;&nbsp;&nbsp;
				<?php } else { ?>
				     <a href="user_login.php" ><img src="foodimage/login5.jpg"></img></a>&nbsp;&nbsp;&nbsp; <a href="user_register.php" ><img src="foodimage/regi.jpg" height="50" width="150"></img></a>
				<?php }?>
				</td>

			</tr>

		</table>
	</div>

<br>
<div id="menu1">
	<table width="100%" border="0">
		  <tr bgcolor="#666666">
				
				<td align="center"  height="40"><a href="index.php" class="color1" ><b style="color:#FFF">Home</b></a></td>
    				
				<td scope="col" id="mobile" onMouseOver="showmenu('abtmob')"  onMouseOut="hidemenu('abtmob')" align="center"><b style="color:#FFF">About Us</b>
    					<table class="menu" width="157" id="abtmob" border="0"  bgcolor="#CCCCCC">
 				 		 <tr>
    						<td class="menu"><a  href="aboutus.php" ><b>About Us</b></a></td>
  						</tr>
						<tr>
    							<td class="menu"><a  href="what_we_are.php" ><b>What We Are?</b></a></td>
  						</tr>
 					      <tr>
 							<td class="menu"><a href="terms_conditions.php" ><b>Terms & Condition</b></a></td>
  						</tr>
					</table>

   				 </td>

<td scope="col" id="mobile" onMouseOver="showmenu('abtmob1')"  onMouseOut="hidemenu('abtmob1')" align="center"><b style="color:#FFF">Product</b>
    		
			<table class="menu" width="138" id="abtmob1" border="0"  bgcolor="#CCCCCC">
 			<tr>
    			<td class="menu"><a  href="product.php?id=snacks" ><b>Snacks</b></a></td>
  			</tr>
  			<tr>
    			<td class="menu"><a  href="product.php?id=starters" ><b>Starters</b></a></td>
  			</tr>
 			<tr>
    			<td class="menu"><a  href="product.php?id=salads" ><b>Salads</b></a></td>
  			</tr>
             <tr>
    			<td class="menu"><a  href="product.php?id=roti" ><b>Roti's</b></a></td>
  			</tr>
  			<tr>
    			<td class="menu"><a  href="product.php?id=sabji" ><b>Sabji's</b></a></td>
  			</tr>
  			<tr>
    			<td class="menu"><a  href="product.php?id=pulav" ><b>pulav's</b></a></td>
  			</tr>
			<tr>
    			<td class="menu"><a  href="product.php?id=deserts" ><b>Deserts</b></a></td>
  			</tr>


					</table>

   				 </td>
				




<td scope="col" align="center" onMouseOver="showmenu('abtelec1')" onMouseOut="hidemenu('abtelec1')"><b style="color:#FFF">Shopping With Us</b>

    <table width="305" bgcolor="#CCCCCC" border="0" class="menu" id="abtelec1">
  <tr>
    <td class="menu"><a href="Payment_option.php"><b>Payment options</b></a></td>
  </tr>

  <tr>
    <td class="menu"><a href="Payment_instruction.php"  ><b>Payment Instructions</b></a></td>
  </tr>

<tr>
    <td class="menu"><a href="Cancellation_policy.php"  ><b>Cancellation Policy</b></a></td>
  </tr>
 </table>
 </td>





 <td scope="col" align="center" onMouseOver="showmenu('abtelec')" onMouseOut="hidemenu('abtelec')"><b style="color:#FFF">My  Account</b>

    <table width="200" bgcolor="#CCCCCC" border="0" class="menu" id="abtelec">
<?php if(isset($_SESSION['username'])){ ?>
 <?php if($_SESSION['usertype'] == "admin"){?>
  <tr>
  <td class="menu"><a href="report.php" ><b>Admin Panel</b></a></td>
  </tr>
  <tr>
  <td class="menu"><a href="user_bill_admin.php" ><b>Billing Information</b></a></td>
  </tr>
  <tr>
  <td class="menu"><a href="checkUser.php" ><b>User Information</b></a></td>
  </tr>
  <tr>
  <td class="menu"><a href="user_feed.php" ><b>User Feedbacks</b></a></td>
  </tr>
 <?php } ?>
  <?php if($_SESSION['usertype'] == "user"){?>
   <tr>
  <td class="menu"><a href="user_bill_info.php" ><b>Billing Information</b></a></td>
  </tr>
 <?php } ?>
    <tr>
 <td class="menu"><a href="selectprods.php" ><b>Food Category</b></a></td>
  </tr>
    <tr>
 <td class="menu"><a href="logout.php" ><b>logout</b></a></td>
  </tr>
<?php }	else { ?>
  <tr>
 <td class="menu"><a href="user_login.php" ><b>sign in</b></a></td>
  </tr>
 <tr>
    <td class="menu"><a href="user_register.php" ><b>Register with us</b></a></td>
  </tr>
<?php } ?>
 </table>
 </td>



				<td align="center"  height="40"><a href="reg_feedback.php" class="color1" ><b style="color:#FFF">Feedback</b></a></td>

				<td align="center"  height="40"><a href="contac_us.php" class="color1" ><b style="color:#FFF">Contact Us</b></a></td>


	</table>

<!-- END OF HEADER -->